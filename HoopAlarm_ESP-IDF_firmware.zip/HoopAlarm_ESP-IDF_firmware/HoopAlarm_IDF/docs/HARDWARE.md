# Hoop Alarm – hardware notes and default pin map

**The pin numbers below are defaults chosen for this firmware.** Neither case study gives the real PCB netlist. Before flashing, check each pin against your schematic and change any that differ in `idf.py menuconfig → Hoop Alarm Clock`.

## Pin map (ESP32-WROOM-32)

| Function | GPIO | Notes |
|---|---|---|
| DS3231 SDA | 21 | I2C at 400 kHz. Internal pull-ups are on; the module's 4k7 pull-ups are fine too |
| DS3231 SCL | 22 | |
| DS3231 INT/SQW | **33** | Open-drain, active low. **Must be an RTC GPIO** (0,2,4,12–15,25–27,32–39) so it can wake the chip from deep sleep (ext0) |
| IR receiver out | 32 | Open-collector. The internal pull-up is enabled. On GPIO34–39, fit an external 10 k pull-up |
| IR emitter enable | 27 | High = emitter powered. Drives a small NPN/MOSFET. The emitter is on only while an alarm rings. Set to `-1` if the emitter is always powered |
| Buzzer | 25 | LEDC PWM → NPN transistor (e.g. S8050/2N2222, 1 k base resistor) → piezo. Add a flyback diode if the buzzer is magnetic |
| Servo signal | 26 | 50 Hz PWM, 500–2400 µs |
| Servo power switch | 4 | High = servo powered (P-MOSFET high-side or N-MOSFET low-side). Set to `-1` if always powered |
| Setup button | **14** | To GND, internal pull-up. **RTC GPIO** so it can wake the chip (ext1). Avoid GPIO0 (strapping) |
| Display SER (data) | 23 | SPI3 (VSPI) MOSI |
| Display SRCK (clock) | 18 | SPI3 SCLK, 1 MHz |
| Display RCK (latch) | 19 | SPI CS line: the rising edge after each frame latches the outputs |
| Display /G (/OE) | 17 | PWM-dimmed at 5 kHz, active low. **Fit a 10 k pull-up to 3V3** so the display stays dark during boot |
| Battery sense | 36 | ADC1_CH0 through a 100 k / 100 k divider (ratio ×2.00). It must be an ADC1 pin, because ADC2 can't be used while BLE is active |
| TP4056 CHRG | 39 | Open-drain, low while charging. Fit an external pull-up (GPIO39 has none) |

## Two builds, one firmware

The two case studies describe two hardware variants. Both are supported, and you choose between them in menuconfig.

| | **Mains build** (default) | **Battery build** |
|---|---|---|
| Kconfig | `HOOP_POWER_MAINS` | `HOOP_POWER_BATTERY` |
| Supply | 5 V wall adapter | 3.7 V 2000 mAh LiPo + TP4056 |
| Display | 4 × two-digit large 7-segment, always on | optional; lit only while awake |
| Sleep | never | deep sleep between alarms (~40 µA board) |
| BLE | always advertising | 120 s window after boot or a button press |

## Display chain

The firmware drives each digit **statically** with one shift register per digit, chained together. Register 1 drives digit 0 (the leftmost digit), unless `HOOP_DISPLAY_CHAIN_REVERSED` is set.

* **Large common-anode digits (recommended):** use the **TPIC6B595**. Its open-drain outputs sink up to 150 mA per segment and tolerate the higher LED string voltage that large digits need. A bit set to 1 lights the segment.
* **74HC595 sinking a common-anode digit directly:** enable `HOOP_DISPLAY_INVERT`.
* Segment order is QA=a … QG=g, QH=DP. If the PCB routes segments differently, edit `SEG_TO_OUTPUT[]` in `display.c`.
* The colon is the DP of digit `HOOP_DISPLAY_COLON_DIGIT` (default 1, the hour units). In 12-hour mode, the DP after the minutes acts as the PM indicator.

8-digit layout: `HH MM SS` followed by two status digits:
* `AL` = an alarm is armed
* `Lo` = battery low
* `b0` = the cradle is empty
* while ringing: `S2` = 2 baskets still needed, or `--` = out of balls

## Power and layout reminders (from the case study)

* Run the **servo power on its own trace** and put a **470–1000 µF bulk capacitor** at the servo connector. The SG90's stall current spikes can brown out the ESP32. The firmware also powers the servo only while it moves and stops the PWM afterwards.
* Keep the antenna keep-out zone of the ESP32 module clear of copper **and** plastic.
* Fit a CR2032 in the DS3231 so time survives a dead LiPo or an unplugged adapter. If the coin cell dies, the clock shows `--------  SEt` until the app sends the time again.
* IR shot detection is debounced in firmware. A pass counts only if the beam is broken for **2 ms – 400 ms** and then restored. Shorter breaks are glitches; longer ones mean a hand or a ball is stuck in the hoop. Hits within **600 ms** of the previous basket (net bounce) and anything during the **servo release** are ignored. All of these thresholds are in menuconfig.
