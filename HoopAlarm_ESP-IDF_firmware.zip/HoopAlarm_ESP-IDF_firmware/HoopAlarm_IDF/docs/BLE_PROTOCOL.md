# Hoop Alarm – BLE protocol (v1)

This is the contract between the firmware and the React Native app. All multi-byte values are **little-endian** and all structs are **packed**. Keep it in sync with `main/hoop_types.h`.

## Connection model

1. The device advertises as `HoopAlarm`. Its 128-bit service UUID is in the scan response.
   * **Mains build:** it advertises all the time (`CONFIG_HOOP_BLE_ADV_WINDOW_S = 0`).
   * **Battery build:** it advertises for 120 s after a cold boot or a short press of the button. Otherwise the radio is off.
2. The app connects, and the device starts security straight away. Pairing uses **LE Secure Connections + MITM + bonding**. The device **displays** a 6-digit passkey and the phone enters it.
   * With the 7-segment display fitted, the display shows a random code as `P 123456`.
   * Without a display, the code is fixed (`CONFIG_HOOP_BLE_STATIC_PASSKEY`, default `246810`). Print it on the product label.
   * Once one phone is bonded, a new phone can pair only within **60 s of a short button press** (`CONFIG_HOOP_BLE_PAIRING_NEEDS_BUTTON`).
3. The app reads the current state, writes its changes, then writes `CMD_END_SESSION` (0x07) to the Command characteristic. The device then disconnects and stops advertising. Keep sessions short. On Android, reconnect when the app resumes instead of holding the link open.

Every characteristic except **Device info** needs an encrypted, authenticated link. Before pairing, reads and writes fail with ATT error 0x05 or 0x0F, which makes the phone OS start pairing.

## UUIDs

The base is `484f4f50-XXXX-4c41-524d-2d4553503332`.

| XXXX | Name | Properties | Size |
|---|---|---|---|
| 0001 | **Service** | | |
| 0002 | Time | Read / Write | R: 8, W: 4 (+2 optional) |
| 0003 | Alarms | Read / Write | 1 + 8·n |
| 0004 | Settings | Read / Write | 16 |
| 0005 | Status | Read / Notify (1 Hz) | 24 |
| 0006 | Log | Read (long read) | 1 + 12·n |
| 0007 | Command | Write | 1–3 |
| 0008 | OTA control | Read / Write | R: 10, W: 5 |
| 0009 | OTA data | Write | ≤ MTU − 3 |
| 000A | Device info | Read (no pairing needed) | 10 |

The ATT MTU is negotiated up to 247.

## Time (0002)

The device keeps **local wall-clock time**: seconds since 1970-01-01 00:00 *local*. It has no timezone database. To build the value on the phone, take the UTC epoch and add the UTC offset in seconds.

Write:
```
u32 local_epoch      // must be >= 2024-01-01
i16 tz_offset_min    // optional, informational
```
The device writes the DS3231 and re-phases its 1 Hz tick. Re-send the time whenever the phone connects; this also covers DST changes.

Read:
```
u32 local_epoch
u8  time_valid        // 0 = never set or the RTC coin cell died
u8  rtc_present
i16 temp_c_x100       // DS3231 die temperature
```

## Alarms (0003)

The app reads and writes the **whole table** in one go: a count followed by up to 8 slots.
```
u8 count
repeat count times (8 bytes):
  u8 enabled          // 0/1
  u8 hour             // 0..23
  u8 minute           // 0..59
  u8 days_mask        // bit0=Sun … bit6=Sat; 0 = one-shot (disables itself after ringing)
  u8 tone             // 0..6, 0xFF = global setting
  u8 volume           // 1..10, 0xFF = global setting
  u8 shots_required   // baskets to silence, 1..9, 0 = global setting
  u8 reserved         // 0
```
An invalid slot rejects the whole write with error 0x80. Changes take effect at once. An alarm that is already ringing keeps going: you cannot cancel it by editing the table.

## Settings (0004)

```
u8  version            // must be 1
u8  volume             // 1..10
u8  tone               // 0..6  (0 Classic, 1 Siren, 2 Chirp, 3 Rising, 4 Pulse, 5 Arcade, 6 Horn)
u8  shots_required     // 1..9  baskets needed to silence the alarm
u8  brightness         // 5..100 %
u8  night_brightness   // 0..100 %
u8  night_start_hour   // 0..23 (start == end disables night dimming)
u8  night_end_hour     // 0..23
u8  use_24h            // 0/1
u8  shot_window_s      // 5..120  time after a ball drops before it counts as a miss
u8  miss_delay_s       // 1..60   wait after a miss before the next ball (default 5)
u8  max_ring_min       // 0 = ring until a basket, else safety cut-off
u16 ramp_after_s       // 10..900 no basket for this long -> volume ramps up (default 90)
u16 reserved
```
To change one field, read the struct, modify it, and write it back.

## Status (0005) – notified every second while subscribed

```
u32 now_epoch
u32 next_alarm_epoch    // 0 = none
u8  state               // 0 idle, 1 ringing, 2 OTA, 3 tone preview
u8  next_alarm_index    // 0xFF = none
u8  shots_made
u8  shots_required
u8  balls_loaded
u8  ring_volume         // current (rises during the ramp)
u16 batt_mv             // 0 on mains build
u8  batt_pct
u8  flags               // b0 on battery, b1 charging, b2 battery low, b3 RTC lost power,
                        // b4 out of balls, b5 servo fitted, b6 display fitted, b7 time valid
i16 temp_c_x100
u8  fw[3]
u8  flags2              // b0 alarm armed, b1 ramping, b2 RTC OK, b3 IR beam blocked
```

## Log (0006)

The log returns the newest entry first, with up to 32 entries. A full log is 385 bytes, so the app must use a long read. Most BLE libraries do this automatically.
```
u8 count
repeat (12 bytes):
  u32 start_epoch
  u8  alarm_index        // 0xFE = test alarm
  u8  result             // 0 basket made, 1 safety cut-off, 2 stopped from app, 3 skipped (device was off)
  u8  shots_made
  u8  balls_dropped
  u16 seconds_to_dismiss
  u8  misses
  u8  ramped             // 1 if the volume ramp kicked in
```

## Command (0007)

| Opcode | Args | Action |
|---|---|---|
| 0x01 | – | Test alarm now (it still needs a basket to stop) |
| 0x02 | `u8 n` | Cradle reloaded with `n` balls (0 = full) |
| 0x03 | `u8 tone, u8 volume` | Preview a tone for 3 s |
| 0x04 | – | Stop the preview |
| 0x05 | – | Drop one ball (servo test) |
| 0x06 | – | Clear the history log |
| 0x07 | – | End the session: disconnect and stop advertising |
| 0x08 | – | Reboot |
| 0x09 | – | Factory reset: settings, alarms, log and bonds. Then reboot |
| 0x0A | – | Stop the ringing alarm. **Refused (0x84)** unless the firmware is built with `CONFIG_HOOP_ALLOW_APP_STOP` |

## Firmware update (0008 / 0009)

1. Write `[0x01][u32 image_size]` to **OTA control**. This is refused with 0x81 while an alarm is ringing.
2. Write the `.bin` in chunks of up to `MTU − 3` bytes to **OTA data**, using write-with-response for flow control.
3. Write `[0x02][u32 crc32]` to **OTA control**. The checksum is CRC-32/ISO-HDLC, the same as zlib `crc32`, computed over the whole image. The device verifies it, switches the boot slot and reboots about 1 s later.
4. `[0x03]` aborts. Disconnecting during an update also aborts it.

Read **OTA control** to get `u8 active, u8 pct, u32 received, u32 size`. If the new image does not boot correctly, the bootloader rolls back to the previous one.

## Device info (000A) – readable before pairing

```
u8 fw[3]
u8 hw_flags        // b0 servo, b1 display, b2 battery build
u8 tone_count
u8 max_alarms
u8 ball_capacity
u8 display_digits  // 0 = no display
u8 log_capacity
u8 protocol        // 1
```

## Application ATT error codes

| Code | Meaning |
|---|---|
| 0x80 | Value out of range |
| 0x81 | Busy (alarm ringing / OTA running) |
| 0x82 | OTA flash or image error |
| 0x83 | OTA CRC mismatch |
| 0x84 | Not allowed in this build |
