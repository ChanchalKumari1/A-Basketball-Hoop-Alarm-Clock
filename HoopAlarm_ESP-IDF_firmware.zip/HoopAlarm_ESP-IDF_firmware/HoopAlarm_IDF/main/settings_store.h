/*
 * settings_store.h - alarms + settings persisted in NVS flash (survive power loss).
 * Thread-safe; readers get copies.
 */
#pragma once

#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"
#include "hoop_types.h"

esp_err_t store_init(void);

void      store_get_settings(hoop_settings_t *out);
bool      store_validate_settings(const hoop_settings_t *s);
esp_err_t store_set_settings(const hoop_settings_t *in);

uint8_t   store_get_alarms(hoop_alarm_t out[HOOP_MAX_ALARMS]);   /* returns count */
bool      store_validate_alarm(const hoop_alarm_t *a);
esp_err_t store_set_alarms(const hoop_alarm_t *in, uint8_t count);
esp_err_t store_disable_alarm(uint8_t index);

uint32_t  store_get_last_fired(void);
esp_err_t store_set_last_fired(uint32_t epoch);

uint8_t   store_get_balls(void);
esp_err_t store_set_balls(uint8_t balls);

esp_err_t store_factory_reset(void);
