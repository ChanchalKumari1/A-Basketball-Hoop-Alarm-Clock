/*
 * power.h - battery monitoring (LiPo + TP4056), setup button, deep sleep.
 *
 * Battery build: when nothing is happening the ESP32 enters deep sleep
 * (~40 uA board current). Wake sources:
 *   ext0  : DS3231 INT/SQW (alarm time reached)            -> ring
 *   ext1  : setup button                                   -> display + BLE window
 *   timer : early backup wake, in case the INT line fails  -> re-check, sleep again
 * Mains build: never sleeps; this module only handles the button.
 */
#pragma once

#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"
#include "esp_sleep.h"

void      power_early_init(void);                 /* first thing in app_main */
esp_err_t power_init(esp_sleep_wakeup_cause_t wake);
void      power_start(void);                      /* after BLE is up */

void      power_note_activity(void);              /* postpone deep sleep */

uint16_t  power_batt_mv(void);
uint8_t   power_batt_pct(void);
bool      power_batt_low(void);
bool      power_charging(void);
