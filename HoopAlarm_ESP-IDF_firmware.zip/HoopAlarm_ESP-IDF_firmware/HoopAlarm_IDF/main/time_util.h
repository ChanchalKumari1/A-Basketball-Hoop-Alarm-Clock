/*
 * time_util.h - timezone-free calendar helpers.
 *
 * The clock keeps LOCAL wall-clock time everywhere (DS3231, tick counter,
 * alarms). "epoch" in this firmware = seconds since 1970-01-01 00:00 local,
 * so no TZ database is needed on the device; the phone app sends local time.
 */
#pragma once

#include <stdint.h>

#define TU_EPOCH_2000   946684800u   /* earliest time the DS3231 can hold */
#define TU_EPOCH_2024   1704067200u  /* below this the time is "not set" */

typedef struct {
    uint16_t year;    /* 2000..2099 */
    uint8_t  month;   /* 1..12 */
    uint8_t  day;     /* 1..31 */
    uint8_t  hour;    /* 0..23 */
    uint8_t  minute;
    uint8_t  second;
    uint8_t  wday;    /* 0 = Sunday */
} tu_datetime_t;

uint32_t tu_make_epoch(int year, int month, int day, int hour, int minute, int second);
void     tu_split_epoch(uint32_t epoch, tu_datetime_t *out);

static inline uint8_t tu_wday(uint32_t epoch)
{
    return (uint8_t)(((epoch / 86400u) + 4u) % 7u);   /* 1970-01-01 was a Thursday */
}
