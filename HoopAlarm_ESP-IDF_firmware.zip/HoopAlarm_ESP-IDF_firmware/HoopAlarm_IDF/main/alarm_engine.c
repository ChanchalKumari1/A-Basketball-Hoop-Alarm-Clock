/*
 * alarm_engine.c - scheduling + "can't snooze" ringing state machine
 *
 * Ringing sequence:
 *   fire -> buzzer on (selected tone/volume), IR armed, servo drops ball #1
 *   basket -> shots_made++ ; if shots_made >= shots_required -> silence, log "made"
 *                            else short ack chirp, next ball after 1.5 s
 *   no basket within shot_window_s -> miss -> wait miss_delay_s (5 s) -> next ball
 *   cradle empty -> keep ringing; the user can throw a ball by hand or reload
 *   no basket for ramp_after_s (90 s) -> volume steps up every 10 s, faster tempo
 */
#include <string.h>
#include "alarm_engine.h"
#include "app_config.h"
#include "timekeeper.h"
#include "time_util.h"
#include "ds3231.h"
#include "shot_sensor.h"
#include "buzzer.h"
#include "servo.h"
#include "settings_store.h"
#include "event_log.h"
#include "power.h"
#include "ota_update.h"
#include "driver/gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "esp_task_wdt.h"
#include "esp_timer.h"
#include "esp_attr.h"
#include "esp_log.h"

static const char *TAG = "engine";

#define POLL_MS          100
#define RTC_INT_SLACK_S  2      /* DS3231 edge vs. our tick phase */
#define PREVIEW_US       (3 * 1000000LL)

typedef enum { PH_WAIT_SHOT, PH_NEXT_BALL_DELAY } ring_phase_t;

typedef struct {
    bool         active;
    bool         is_test;
    uint8_t      idx;
    uint32_t     start_epoch;
    int64_t      start_us;
    int64_t      progress_us;      /* last start / basket - drives the 90 s ramp */
    uint8_t      tone;
    uint8_t      volume;
    uint8_t      shots_req;
    uint8_t      shots_made;
    uint8_t      balls_dropped;
    uint8_t      misses;
    bool         ramped;
    int64_t      next_ramp_us;
    ring_phase_t phase;
    int64_t      deadline_us;      /* 0 = none */
    bool         out_of_balls;
} ring_t;

static QueueHandle_t            s_q;
static SemaphoreHandle_t        s_ready;
static esp_sleep_wakeup_cause_t s_wake;

static hoop_settings_t s_set;
static hoop_alarm_t    s_alarms[HOOP_MAX_ALARMS];
static uint8_t         s_alarm_count;

static volatile uint32_t s_next_epoch;     /* 0 = nothing scheduled */
static int               s_next_idx = -1;
static uint32_t          s_rtc_programmed = UINT32_MAX;
static uint32_t          s_last_fired;
static uint8_t           s_balls;

static ring_t            s_ring;
static volatile bool     s_ringing;
static int64_t           s_preview_until_us;

static portMUX_TYPE      s_st_mux = portMUX_INITIALIZER_UNLOCKED;
static hoop_status_t     s_status;

/* ------------------------------------------------------------------ ISR hooks */

static void IRAM_ATTR tick_from_isr(uint32_t epoch, BaseType_t *woken)
{
    hoop_event_t ev = { .type = EV_TICK, .u32 = epoch };
    xQueueSendFromISR(s_q, &ev, woken);
}

static void IRAM_ATTR rtc_int_isr(void *arg)
{
    hoop_event_t ev = { .type = EV_RTC_INT };
    BaseType_t woken = pdFALSE;
    xQueueSendToFrontFromISR(s_q, &ev, &woken);
    if (woken) {
        portYIELD_FROM_ISR();
    }
}

static void on_shot(uint32_t pass_ms)
{
    alarm_engine_post(EV_SHOT, 0, 0, pass_ms);
}

/* ------------------------------------------------------------------ scheduling */

static uint32_t next_occurrence(const hoop_alarm_t *a, uint32_t from)
{
    uint32_t day0 = from - (from % 86400u);
    for (uint32_t d = 0; d <= 7; d++) {
        uint32_t day  = day0 + d * 86400u;
        uint32_t cand = day + a->hour * 3600u + a->minute * 60u;
        if (cand < from || cand <= s_last_fired) {
            continue;
        }
        if (a->days_mask == 0 || (a->days_mask & (1u << tu_wday(day)))) {
            return cand;
        }
    }
    return 0;
}

static void program_rtc(uint32_t epoch)
{
    if (epoch == s_rtc_programmed || !ds3231_present()) {
        return;
    }
    esp_err_t err = epoch ? ds3231_set_alarm1(epoch) : ds3231_disable_alarm1();
    if (err == ESP_OK) {
        s_rtc_programmed = epoch;
    } else {
        ESP_LOGW(TAG, "could not program DS3231 alarm (%s) - tick path still active",
                 esp_err_to_name(err));
    }
}

static void reschedule(uint32_t from)
{
    uint32_t best = 0;
    int      bi = -1;
    if (timekeeper_valid()) {
        for (uint8_t i = 0; i < s_alarm_count; i++) {
            if (!s_alarms[i].enabled) {
                continue;
            }
            uint32_t c = next_occurrence(&s_alarms[i], from);
            if (c && (best == 0 || c < best)) {
                best = c;
                bi = i;
            }
        }
    }
    s_next_epoch = best;
    s_next_idx = bi;
    program_rtc(best);

    if (best) {
        tu_datetime_t dt;
        tu_split_epoch(best, &dt);
        ESP_LOGI(TAG, "next alarm #%d at %04u-%02u-%02u %02u:%02u", bi, dt.year, dt.month,
                 dt.day, dt.hour, dt.minute);
    } else {
        ESP_LOGI(TAG, "no alarm scheduled%s", timekeeper_valid() ? "" : " (time not set)");
    }
}

static void reload_config(void)
{
    store_get_settings(&s_set);
    s_alarm_count = store_get_alarms(s_alarms);
}

/* ------------------------------------------------------------------ ringing */

static void drop_next_ball(int64_t now)
{
    if (HOOP_HAS_SERVO && s_balls > 0 && servo_busy()) {
        s_ring.phase = PH_NEXT_BALL_DELAY;          /* servo still moving - retry shortly */
        s_ring.deadline_us = now + 200000;
        return;
    }
    if (HOOP_HAS_SERVO && s_balls > 0 && servo_request_drop()) {
        s_balls--;
        s_ring.balls_dropped++;
        s_ring.out_of_balls = false;
        s_ring.phase = PH_WAIT_SHOT;
        s_ring.deadline_us = now + ((int64_t)s_set.shot_window_s * 1000 + HOOP_SERVO_CYCLE_MS) * 1000;
        ESP_LOGI(TAG, "ball %u dropped (%u left)", s_ring.balls_dropped, s_balls);
    } else {
        /* no servo / empty cradle: wait for a hand-thrown basket, no miss timing */
        s_ring.phase = PH_WAIT_SHOT;
        s_ring.deadline_us = 0;
        s_ring.out_of_balls = HOOP_HAS_SERVO;
        if (HOOP_HAS_SERVO) {
            ESP_LOGW(TAG, "cradle empty - waiting for a basket");
        }
    }
}

static void ring_start(int idx, const hoop_alarm_t *a, bool is_test)
{
    memset(&s_ring, 0, sizeof(s_ring));
    int64_t now = esp_timer_get_time();

    s_ring.active      = true;
    s_ring.is_test     = is_test;
    s_ring.idx         = is_test ? HOOP_TEST_ALARM_IDX : (uint8_t)idx;
    s_ring.start_epoch = timekeeper_now();
    s_ring.start_us    = now;
    s_ring.progress_us = now;
    s_ring.tone        = (a && a->tone != HOOP_USE_GLOBAL) ? a->tone : s_set.tone;
    s_ring.volume      = (a && a->volume != HOOP_USE_GLOBAL) ? a->volume : s_set.volume;
    s_ring.shots_req   = (a && a->shots_required) ? a->shots_required : s_set.shots_required;
    if (s_ring.volume == 0) {
        s_ring.volume = 1;            /* an alarm is never silent */
    }
    if (s_ring.shots_req == 0) {
        s_ring.shots_req = 1;
    }
    s_preview_until_us = 0;
    s_ringing = true;

    ESP_LOGW(TAG, "ALARM %s#%d - %u basket(s) needed", is_test ? "(test) " : "", idx,
             s_ring.shots_req);

    buzzer_play(s_ring.tone, s_ring.volume, true);
    shot_sensor_arm(true);
    power_note_activity();
    drop_next_ball(now);
}

static void ring_finish(hoop_log_result_t result)
{
    int64_t now = esp_timer_get_time();
    buzzer_stop();
    if (result == LOG_RESULT_MADE) {
        buzzer_jingle(JINGLE_SUCCESS);
    }
    shot_sensor_arm(false);

    hoop_log_entry_t e = {
        .start_epoch = s_ring.start_epoch,
        .alarm_index = s_ring.idx,
        .result = (uint8_t)result,
        .shots_made = s_ring.shots_made,
        .balls_dropped = s_ring.balls_dropped,
        .seconds_to_dismiss = (uint16_t)((now - s_ring.start_us) / 1000000),
        .misses = s_ring.misses,
        .ramped = s_ring.ramped,
    };
    event_log_add(&e);
    store_set_balls(s_balls);

    ESP_LOGW(TAG, "alarm finished: result %d after %u s, %u basket(s), %u miss(es)",
             result, e.seconds_to_dismiss, e.shots_made, e.misses);

    s_ring.active = false;
    s_ringing = false;
    reschedule(timekeeper_now());
    power_note_activity();
}

static void ring_on_shot(void)
{
    if (!s_ring.active) {
        return;
    }
    int64_t now = esp_timer_get_time();
    s_ring.shots_made++;
    s_ring.progress_us = now;
    ESP_LOGI(TAG, "basket %u/%u", s_ring.shots_made, s_ring.shots_req);

    if (s_ring.shots_made >= s_ring.shots_req) {
        ring_finish(LOG_RESULT_MADE);
    } else {
        buzzer_jingle(JINGLE_ACK);
        s_ring.phase = PH_NEXT_BALL_DELAY;
        s_ring.deadline_us = now + (int64_t)HOOP_AFTER_MADE_DELAY_MS * 1000;
    }
}

static void ring_poll(void)
{
    int64_t now = esp_timer_get_time();

    if (!s_ring.active) {
        if (s_preview_until_us && now >= s_preview_until_us) {
            s_preview_until_us = 0;
            buzzer_stop();
        }
        return;
    }

    /* no basket for ramp_after_s -> get louder and faster */
    if (!s_ring.ramped && now - s_ring.progress_us >= (int64_t)s_set.ramp_after_s * 1000000) {
        s_ring.ramped = true;
        s_ring.next_ramp_us = now;
        buzzer_set_tempo(65);
        ESP_LOGW(TAG, "no basket for %u s - ramping volume", s_set.ramp_after_s);
    }
    if (s_ring.ramped && now >= s_ring.next_ramp_us) {
        if (s_ring.volume < HOOP_VOLUME_MAX) {
            s_ring.volume++;
            buzzer_set_volume(s_ring.volume);
        }
        s_ring.next_ramp_us = now + (int64_t)HOOP_RAMP_STEP_MS * 1000;
    }

    switch (s_ring.phase) {
    case PH_WAIT_SHOT:
        if (s_ring.deadline_us && now >= s_ring.deadline_us) {
            s_ring.misses++;
            s_ring.phase = PH_NEXT_BALL_DELAY;
            s_ring.deadline_us = now + (int64_t)s_set.miss_delay_s * 1000000;
            ESP_LOGI(TAG, "miss #%u - next ball in %u s", s_ring.misses, s_set.miss_delay_s);
        }
        break;
    case PH_NEXT_BALL_DELAY:
        if (now >= s_ring.deadline_us && !servo_busy()) {
            drop_next_ball(now);
        }
        break;
    }

    if (s_set.max_ring_min && now - s_ring.start_us >= (int64_t)s_set.max_ring_min * 60000000LL) {
        ESP_LOGW(TAG, "safety cut-off after %u min", s_set.max_ring_min);
        ring_finish(LOG_RESULT_TIMEOUT);
    }
}

/* ------------------------------------------------------------------ firing */

static void fire(uint32_t epoch)
{
    int idx = s_next_idx;
    hoop_alarm_t a = s_alarms[idx];

    s_last_fired = epoch;
    store_set_last_fired(epoch);
    if (a.days_mask == 0) {                 /* one-shot alarm disarms itself */
        store_disable_alarm((uint8_t)idx);
        s_alarms[idx].enabled = 0;
    }
    ring_start(idx, &a, false);
    reschedule(timekeeper_now());
}

static void check_due(uint32_t now, bool from_rtc)
{
    if (s_ring.active || s_next_epoch == 0 || s_next_idx < 0) {
        return;
    }
    int32_t late = (int32_t)(now - s_next_epoch);
    if (late < (from_rtc ? -RTC_INT_SLACK_S : 0)) {
        return;
    }
    if (late > HOOP_ALARM_GRACE_S) {
        ESP_LOGW(TAG, "alarm #%d missed by %ld s (device off) - skipped", s_next_idx, (long)late);
        hoop_log_entry_t e = {
            .start_epoch = s_next_epoch,
            .alarm_index = (uint8_t)s_next_idx,
            .result = LOG_RESULT_SKIPPED,
        };
        event_log_add(&e);
        s_last_fired = s_next_epoch;
        store_set_last_fired(s_next_epoch);
        reschedule(now);
        return;
    }
    fire(s_next_epoch);
}

/* ------------------------------------------------------------------ status */

static void update_status(void)
{
    hoop_status_t st = {0};
    st.now_epoch        = timekeeper_now();
    st.next_alarm_epoch = s_next_epoch;
    st.next_alarm_index = s_next_idx < 0 ? 0xFF : (uint8_t)s_next_idx;
    st.state = ota_update_in_progress() ? HOOP_STATE_OTA :
               s_ring.active            ? HOOP_STATE_RINGING :
               s_preview_until_us       ? HOOP_STATE_PREVIEW : HOOP_STATE_IDLE;
    st.shots_made     = s_ring.active ? s_ring.shots_made : 0;
    st.shots_required = s_ring.active ? s_ring.shots_req : s_set.shots_required;
    st.balls_loaded   = s_balls;
    st.ring_volume    = s_ring.active ? s_ring.volume : s_set.volume;
    st.batt_mv        = power_batt_mv();
    st.batt_pct       = power_batt_pct();
    st.temp_c_x100    = timekeeper_temperature();
    st.fw[0] = HOOP_FW_MAJOR;
    st.fw[1] = HOOP_FW_MINOR;
    st.fw[2] = HOOP_FW_PATCH;

    if (HOOP_ON_BATTERY)            st.flags |= ST_F_ON_BATTERY;
    if (power_charging())           st.flags |= ST_F_CHARGING;
    if (power_batt_low())           st.flags |= ST_F_BATT_LOW;
    if (ds3231_lost_power())        st.flags |= ST_F_RTC_LOST_POWER;
    if (s_ring.out_of_balls || (HOOP_HAS_SERVO && s_balls == 0)) st.flags |= ST_F_OUT_OF_BALLS;
    if (HOOP_HAS_SERVO)             st.flags |= ST_F_HAS_SERVO;
    if (HOOP_HAS_DISPLAY)           st.flags |= ST_F_HAS_DISPLAY;
    if (timekeeper_valid())         st.flags |= ST_F_TIME_VALID;

    if (s_next_epoch)               st.flags2 |= ST_F2_ALARM_ARMED;
    if (s_ring.active && s_ring.ramped) st.flags2 |= ST_F2_RAMPING;
    if (ds3231_present())           st.flags2 |= ST_F2_RTC_OK;
    if (shot_sensor_is_blocked())   st.flags2 |= ST_F2_IR_BLOCKED;

    portENTER_CRITICAL(&s_st_mux);
    s_status = st;
    portEXIT_CRITICAL(&s_st_mux);
}

/* ------------------------------------------------------------------ events */

static void handle(const hoop_event_t *ev)
{
    switch (ev->type) {
    case EV_TICK:
        check_due(ev->u32, false);
        break;

    case EV_RTC_INT: {
        bool fired = false;
        ds3231_check_and_clear_alarm1(&fired);
        if (fired) {
            ESP_LOGI(TAG, "DS3231 alarm interrupt");
            s_rtc_programmed = UINT32_MAX;     /* re-arm on next reschedule */
            check_due(timekeeper_now(), true);
            if (!s_ring.active) {
                reschedule(timekeeper_now());
            }
        }
        break;
    }

    case EV_SHOT:
        ring_on_shot();
        break;

    case EV_CONFIG_CHANGED:
        reload_config();
        reschedule(timekeeper_now());
        break;

    case EV_TIME_CHANGED:
        s_rtc_programmed = UINT32_MAX;
        reschedule(timekeeper_now());
        break;

    case EV_CMD_TEST:
        if (!s_ring.active) {
            ring_start(HOOP_TEST_ALARM_IDX, NULL, true);
        }
        break;

    case EV_CMD_RELOAD: {
        uint8_t n = ev->a ? ev->a : HOOP_BALL_CAPACITY;
        s_balls = n > HOOP_BALL_CAPACITY ? HOOP_BALL_CAPACITY : n;
        if (!s_ring.active) {
            store_set_balls(s_balls);
        } else if (s_ring.out_of_balls) {
            s_ring.phase = PH_NEXT_BALL_DELAY;
            s_ring.deadline_us = esp_timer_get_time() + 2000000;
        }
        ESP_LOGI(TAG, "cradle reloaded: %u ball(s)", s_balls);
        break;
    }

    case EV_CMD_APP_STOP:
#if HOOP_ALLOW_APP_STOP
        if (s_ring.active) {
            ring_finish(LOG_RESULT_APP_STOP);
        }
#else
        ESP_LOGW(TAG, "app stop refused - sink a basket!");
#endif
        break;

    case EV_CMD_DROP_BALL:
        if (!s_ring.active && HOOP_HAS_SERVO && s_balls > 0 && servo_request_drop()) {
            s_balls--;
            store_set_balls(s_balls);
        }
        break;

    case EV_CMD_PREVIEW:
        if (!s_ring.active) {
            buzzer_play(ev->a, ev->b ? ev->b : s_set.volume, true);
            s_preview_until_us = esp_timer_get_time() + PREVIEW_US;
        }
        break;

    case EV_CMD_PREVIEW_STOP:
        if (!s_ring.active && s_preview_until_us) {
            s_preview_until_us = 0;
            buzzer_stop();
        }
        break;

    default:
        break;
    }
}

/* ------------------------------------------------------------------ task */

static void engine_task(void *arg)
{
    /* Core-1 peripheral setup: every ISR below is allocated on this core,
     * so BLE activity on core 0 can never delay the alarm path. */
    esp_err_t err = gpio_install_isr_service(0);
    if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) {
        ESP_LOGE(TAG, "gpio isr service: %s", esp_err_to_name(err));
    }

    gpio_config_t io = {
        .pin_bit_mask = 1ULL << PIN_RTC_INT,
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .intr_type = GPIO_INTR_NEGEDGE,
    };
    gpio_config(&io);
    gpio_isr_handler_add(PIN_RTC_INT, rtc_int_isr, NULL);

    shot_sensor_init(on_shot);
    timekeeper_init(tick_from_isr);

    reload_config();
    s_last_fired = store_get_last_fired();
    s_balls = store_get_balls();

    uint32_t now = timekeeper_now();
    bool rtc_fired = false;
    ds3231_check_and_clear_alarm1(&rtc_fired);

    /* Look back over the grace window so an alarm that triggered this very wake-up
     * (or was due during a reboot) is still found and fired. */
    reschedule(now > HOOP_ALARM_GRACE_S ? now - HOOP_ALARM_GRACE_S : 0);
    check_due(now, rtc_fired || s_wake == ESP_SLEEP_WAKEUP_EXT0);
    update_status();

    xSemaphoreGive(s_ready);

    esp_task_wdt_add(NULL);
    for (;;) {
        esp_task_wdt_reset();
        hoop_event_t ev;
        if (xQueueReceive(s_q, &ev, pdMS_TO_TICKS(POLL_MS)) == pdTRUE) {
            handle(&ev);
        }
        ring_poll();
        update_status();
    }
}

/* ------------------------------------------------------------------ public */

void alarm_engine_start(esp_sleep_wakeup_cause_t wake)
{
    s_wake = wake;
    s_q = xQueueCreate(32, sizeof(hoop_event_t));
    s_ready = xSemaphoreCreateBinary();
    xTaskCreatePinnedToCore(engine_task, "engine", 4096, NULL, PRIO_ENGINE, NULL, CORE_REALTIME);
    xSemaphoreTake(s_ready, portMAX_DELAY);
}

bool alarm_engine_post(uint8_t type, uint8_t a, uint8_t b, uint32_t u32)
{
    if (!s_q) {
        return false;
    }
    hoop_event_t ev = { .type = type, .a = a, .b = b, .u32 = u32 };
    return xQueueSend(s_q, &ev, pdMS_TO_TICKS(50)) == pdTRUE;
}

void alarm_engine_get_status(hoop_status_t *out)
{
    portENTER_CRITICAL(&s_st_mux);
    *out = s_status;
    portEXIT_CRITICAL(&s_st_mux);
}

bool alarm_engine_is_ringing(void)
{
    return s_ringing;
}

bool alarm_engine_is_busy(void)
{
    return s_ringing || s_preview_until_us != 0;
}

uint32_t alarm_engine_seconds_to_next(void)
{
    uint32_t next = s_next_epoch;
    uint32_t now = timekeeper_now();
    if (next == 0) {
        return 0;
    }
    return next > now ? next - now : 1;
}
