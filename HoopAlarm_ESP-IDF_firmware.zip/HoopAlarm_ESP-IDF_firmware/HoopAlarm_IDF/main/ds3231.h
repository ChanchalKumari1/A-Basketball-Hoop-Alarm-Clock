/*
 * ds3231.h - DS3231 temperature-compensated RTC over I2C (address 0x68).
 * All functions are thread-safe (internal mutex). Time is local wall-clock.
 */
#pragma once

#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"

esp_err_t ds3231_init(int sda_gpio, int scl_gpio);
bool      ds3231_present(void);

/* true if the oscillator stopped (coin cell flat/removed) since the time was last set */
bool      ds3231_lost_power(void);

esp_err_t ds3231_get_epoch(uint32_t *epoch);
esp_err_t ds3231_set_epoch(uint32_t epoch);   /* also resets the 1 Hz countdown chain */

/* Alarm 1: match date + hour + minute + second -> INT pin pulled low */
esp_err_t ds3231_set_alarm1(uint32_t epoch);
esp_err_t ds3231_disable_alarm1(void);
esp_err_t ds3231_check_and_clear_alarm1(bool *fired);

esp_err_t ds3231_get_temperature(int16_t *c_x100);
