/*
 * buzzer.h - piezo buzzer on an ESP32 GPIO (via NPN transistor), LEDC PWM.
 * Tone = repeating pattern of {frequency, duration}; volume = PWM duty.
 * Selectable from the app (HOOP_TONE_COUNT patterns).
 */
#pragma once

#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"

typedef enum {
    JINGLE_BOOT = 0,
    JINGLE_ACK,        /* basket made, more needed */
    JINGLE_SUCCESS,    /* alarm dismissed */
    JINGLE_ERROR,
    JINGLE_BLE,
} buzzer_jingle_t;

esp_err_t   buzzer_init(void);

void        buzzer_play(uint8_t tone, uint8_t volume, bool loop);
void        buzzer_stop(void);
void        buzzer_set_volume(uint8_t volume);       /* 0..10, applied from next note */
void        buzzer_set_tempo(uint8_t percent);       /* note length %, 100 = normal */
void        buzzer_jingle(buzzer_jingle_t j);        /* plays once, then resumes the tone */
bool        buzzer_is_active(void);
const char *buzzer_tone_name(uint8_t tone);
