/*
 * ds3231.c - DS3231 RTC driver (ESP-IDF i2c_master driver, IDF >= 5.2)
 */
#include <string.h>
#include "ds3231.h"
#include "time_util.h"
#include "driver/i2c_master.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "esp_check.h"
#include "esp_log.h"

static const char *TAG = "ds3231";

#define DS3231_ADDR        0x68
#define I2C_TIMEOUT_MS     50

#define REG_SECONDS        0x00
#define REG_A1_SECONDS     0x07
#define REG_CONTROL        0x0E
#define REG_STATUS         0x0F
#define REG_TEMP_MSB       0x11

#define CTRL_EOSC          0x80   /* 1 = oscillator stops on battery */
#define CTRL_BBSQW         0x40
#define CTRL_INTCN         0x04   /* 1 = INT/SQW pin is the alarm interrupt */
#define CTRL_A2IE          0x02
#define CTRL_A1IE          0x01

#define ST_OSF             0x80
#define ST_EN32KHZ         0x08
#define ST_A2F             0x02
#define ST_A1F             0x01

static i2c_master_bus_handle_t s_bus;
static i2c_master_dev_handle_t s_dev;
static SemaphoreHandle_t       s_mtx;
static bool                    s_present;
static bool                    s_lost_power;

#define LOCK()   xSemaphoreTake(s_mtx, portMAX_DELAY)
#define UNLOCK() xSemaphoreGive(s_mtx)

static inline uint8_t bcd2bin(uint8_t v) { return (uint8_t)((v & 0x0F) + (v >> 4) * 10); }
static inline uint8_t bin2bcd(uint8_t v) { return (uint8_t)(((v / 10) << 4) | (v % 10)); }

static esp_err_t rd(uint8_t reg, uint8_t *buf, size_t n)
{
    return i2c_master_transmit_receive(s_dev, &reg, 1, buf, n, I2C_TIMEOUT_MS);
}

static esp_err_t wr(uint8_t reg, const uint8_t *buf, size_t n)
{
    uint8_t tmp[8];
    if (n > sizeof(tmp) - 1) {
        return ESP_ERR_INVALID_ARG;
    }
    tmp[0] = reg;
    memcpy(&tmp[1], buf, n);
    return i2c_master_transmit(s_dev, tmp, n + 1, I2C_TIMEOUT_MS);
}

static esp_err_t update_reg(uint8_t reg, uint8_t clear_mask, uint8_t set_mask)
{
    uint8_t v;
    esp_err_t err = rd(reg, &v, 1);
    if (err == ESP_OK) {
        v = (uint8_t)((v & ~clear_mask) | set_mask);
        err = wr(reg, &v, 1);
    }
    return err;
}

esp_err_t ds3231_init(int sda_gpio, int scl_gpio)
{
    s_mtx = xSemaphoreCreateMutex();
    ESP_RETURN_ON_FALSE(s_mtx, ESP_ERR_NO_MEM, TAG, "mutex");

    i2c_master_bus_config_t bus_cfg = {
        .i2c_port = I2C_NUM_0,
        .sda_io_num = sda_gpio,
        .scl_io_num = scl_gpio,
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .glitch_ignore_cnt = 7,
        .flags.enable_internal_pullup = true,   /* modules normally carry 4k7 too */
    };
    ESP_RETURN_ON_ERROR(i2c_new_master_bus(&bus_cfg, &s_bus), TAG, "i2c bus");

    i2c_device_config_t dev_cfg = {
        .dev_addr_length = I2C_ADDR_BIT_LEN_7,
        .device_address = DS3231_ADDR,
        .scl_speed_hz = 400000,
    };
    ESP_RETURN_ON_ERROR(i2c_master_bus_add_device(s_bus, &dev_cfg, &s_dev), TAG, "i2c dev");

    esp_err_t err = ESP_FAIL;
    for (int attempt = 0; attempt < 3 && err != ESP_OK; attempt++) {
        err = i2c_master_probe(s_bus, DS3231_ADDR, I2C_TIMEOUT_MS);
        if (err != ESP_OK) {
            vTaskDelay(pdMS_TO_TICKS(20));
        }
    }
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "DS3231 not found on I2C (SDA=%d SCL=%d)", sda_gpio, scl_gpio);
        return err;
    }

    LOCK();
    uint8_t st = 0;
    err = rd(REG_STATUS, &st, 1);
    if (err == ESP_OK) {
        s_lost_power = (st & ST_OSF) != 0;
        /* Oscillator runs on the coin cell, INT pin = alarm interrupt, no square wave,
         * alarm 2 off. */
        err = update_reg(REG_CONTROL, CTRL_EOSC | CTRL_BBSQW | CTRL_A2IE, CTRL_INTCN);
    }
    if (err == ESP_OK) {
        /* 32 kHz output off (saves power). Keep A1F: boot code checks if the alarm fired.
         * Writing 1 to OSF/A1F leaves them unchanged. */
        err = update_reg(REG_STATUS, ST_EN32KHZ | ST_A2F, 0);
    }
    UNLOCK();

    if (err == ESP_OK) {
        s_present = true;
        ESP_LOGI(TAG, "DS3231 ready%s", s_lost_power ? " (oscillator had stopped - time needs setting)" : "");
    }
    return err;
}

bool ds3231_present(void)    { return s_present; }
bool ds3231_lost_power(void) { return s_lost_power; }

esp_err_t ds3231_get_epoch(uint32_t *epoch)
{
    ESP_RETURN_ON_FALSE(s_present, ESP_ERR_INVALID_STATE, TAG, "absent");
    uint8_t r[7];
    LOCK();
    esp_err_t err = rd(REG_SECONDS, r, sizeof(r));
    UNLOCK();
    if (err != ESP_OK) {
        return err;
    }

    uint8_t sec = bcd2bin(r[0] & 0x7F);
    uint8_t min = bcd2bin(r[1] & 0x7F);
    uint8_t hour;
    if (r[2] & 0x40) {                       /* 12 h mode (never written by us, but handle it) */
        hour = bcd2bin(r[2] & 0x1F);
        if (hour == 12) {
            hour = 0;
        }
        if (r[2] & 0x20) {
            hour += 12;
        }
    } else {
        hour = bcd2bin(r[2] & 0x3F);
    }
    uint8_t  day   = bcd2bin(r[4] & 0x3F);
    uint8_t  month = bcd2bin(r[5] & 0x1F);
    uint16_t year  = (uint16_t)(2000 + bcd2bin(r[6]) + ((r[5] & 0x80) ? 100 : 0));

    if (sec > 59 || min > 59 || hour > 23 || day < 1 || day > 31 || month < 1 || month > 12) {
        return ESP_ERR_INVALID_RESPONSE;
    }
    *epoch = tu_make_epoch(year, month, day, hour, min, sec);
    return ESP_OK;
}

esp_err_t ds3231_set_epoch(uint32_t epoch)
{
    ESP_RETURN_ON_FALSE(s_present, ESP_ERR_INVALID_STATE, TAG, "absent");
    ESP_RETURN_ON_FALSE(epoch >= TU_EPOCH_2000, ESP_ERR_INVALID_ARG, TAG, "before 2000");

    tu_datetime_t dt;
    tu_split_epoch(epoch, &dt);
    uint8_t r[7] = {
        bin2bcd(dt.second),
        bin2bcd(dt.minute),
        bin2bcd(dt.hour),                    /* bit6 = 0 -> 24 h mode */
        (uint8_t)(dt.wday + 1),              /* DS3231 day-of-week 1..7 */
        bin2bcd(dt.day),
        (uint8_t)(bin2bcd(dt.month) | (dt.year >= 2100 ? 0x80 : 0)),
        bin2bcd((uint8_t)(dt.year % 100)),
    };

    LOCK();
    esp_err_t err = wr(REG_SECONDS, r, sizeof(r));
    if (err == ESP_OK) {
        err = update_reg(REG_STATUS, ST_OSF, 0);
    }
    UNLOCK();
    if (err == ESP_OK) {
        s_lost_power = false;
    }
    return err;
}

esp_err_t ds3231_set_alarm1(uint32_t epoch)
{
    ESP_RETURN_ON_FALSE(s_present, ESP_ERR_INVALID_STATE, TAG, "absent");
    tu_datetime_t dt;
    tu_split_epoch(epoch, &dt);

    /* A1M1..A1M4 = 0, DY/DT = 0  ->  alarm when date, hours, minutes and seconds match */
    uint8_t a[4] = {
        bin2bcd(dt.second),
        bin2bcd(dt.minute),
        bin2bcd(dt.hour),
        bin2bcd(dt.day),
    };

    LOCK();
    esp_err_t err = wr(REG_A1_SECONDS, a, sizeof(a));
    if (err == ESP_OK) {
        err = update_reg(REG_CONTROL, 0, CTRL_INTCN | CTRL_A1IE);
    }
    if (err == ESP_OK) {
        err = update_reg(REG_STATUS, ST_A1F, 0);   /* release INT line */
    }
    UNLOCK();

    if (err == ESP_OK) {
        ESP_LOGI(TAG, "Alarm1 armed for %04u-%02u-%02u %02u:%02u:%02u",
                 dt.year, dt.month, dt.day, dt.hour, dt.minute, dt.second);
    }
    return err;
}

esp_err_t ds3231_disable_alarm1(void)
{
    ESP_RETURN_ON_FALSE(s_present, ESP_ERR_INVALID_STATE, TAG, "absent");
    LOCK();
    esp_err_t err = update_reg(REG_CONTROL, CTRL_A1IE, 0);
    if (err == ESP_OK) {
        err = update_reg(REG_STATUS, ST_A1F, 0);
    }
    UNLOCK();
    return err;
}

esp_err_t ds3231_check_and_clear_alarm1(bool *fired)
{
    *fired = false;
    ESP_RETURN_ON_FALSE(s_present, ESP_ERR_INVALID_STATE, TAG, "absent");
    uint8_t st;
    LOCK();
    esp_err_t err = rd(REG_STATUS, &st, 1);
    if (err == ESP_OK && (st & ST_A1F)) {
        *fired = true;
        st &= (uint8_t)~(ST_A1F | ST_A2F);
        err = wr(REG_STATUS, &st, 1);
    }
    UNLOCK();
    return err;
}

esp_err_t ds3231_get_temperature(int16_t *c_x100)
{
    ESP_RETURN_ON_FALSE(s_present, ESP_ERR_INVALID_STATE, TAG, "absent");
    uint8_t t[2];
    LOCK();
    esp_err_t err = rd(REG_TEMP_MSB, t, 2);
    UNLOCK();
    if (err == ESP_OK) {
        *c_x100 = (int16_t)((int8_t)t[0] * 100 + (t[1] >> 6) * 25);
    }
    return err;
}
