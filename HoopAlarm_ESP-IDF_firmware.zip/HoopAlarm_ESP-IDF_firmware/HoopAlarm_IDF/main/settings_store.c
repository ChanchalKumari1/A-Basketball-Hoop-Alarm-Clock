/*
 * settings_store.c - NVS persistence
 */
#include <string.h>
#include "settings_store.h"
#include "app_config.h"
#include "nvs_flash.h"
#include "nvs.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "esp_check.h"
#include "esp_log.h"

static const char *TAG = "store";

#define NVS_NS          "hoop"
#define KEY_SETTINGS    "settings"
#define KEY_ALARMS      "alarms"
#define KEY_ACOUNT      "acount"
#define KEY_LASTFIRED   "lastfired"
#define KEY_BALLS       "balls"

static nvs_handle_t       s_nvs;
static SemaphoreHandle_t  s_mtx;
static hoop_settings_t    s_set;
static hoop_alarm_t       s_alarms[HOOP_MAX_ALARMS];
static uint8_t            s_count;
static uint32_t           s_last_fired;
static uint8_t            s_balls;

#define LOCK()   xSemaphoreTake(s_mtx, portMAX_DELAY)
#define UNLOCK() xSemaphoreGive(s_mtx)

static void default_settings(hoop_settings_t *s)
{
    memset(s, 0, sizeof(*s));
    s->version          = HOOP_SETTINGS_VER;
    s->volume           = 7;
    s->tone             = 0;
    s->shots_required   = 1;
    s->brightness       = 100;
    s->night_brightness = 15;
    s->night_start_hour = 22;
    s->night_end_hour   = 6;
    s->use_24h          = 1;
    s->shot_window_s    = 20;
    s->miss_delay_s     = 5;
    s->max_ring_min     = CONFIG_HOOP_DEFAULT_MAX_RING_MIN;
    s->ramp_after_s     = 90;
}

bool store_validate_settings(const hoop_settings_t *s)
{
    return s->version == HOOP_SETTINGS_VER &&
           s->volume >= 1 && s->volume <= HOOP_VOLUME_MAX &&
           s->tone < HOOP_TONE_COUNT &&
           s->shots_required >= 1 && s->shots_required <= HOOP_SHOTS_MAX &&
           s->brightness >= 5 && s->brightness <= 100 &&
           s->night_brightness <= 100 &&
           s->night_start_hour < 24 && s->night_end_hour < 24 &&
           s->use_24h <= 1 &&
           s->shot_window_s >= 5 && s->shot_window_s <= 120 &&
           s->miss_delay_s >= 1 && s->miss_delay_s <= 60 &&
           s->ramp_after_s >= 10 && s->ramp_after_s <= 900;
}

bool store_validate_alarm(const hoop_alarm_t *a)
{
    return a->enabled <= 1 &&
           a->hour < 24 && a->minute < 60 &&
           a->days_mask <= 0x7F &&
           (a->tone == HOOP_USE_GLOBAL || a->tone < HOOP_TONE_COUNT) &&
           (a->volume == HOOP_USE_GLOBAL || (a->volume >= 1 && a->volume <= HOOP_VOLUME_MAX)) &&
           a->shots_required <= HOOP_SHOTS_MAX;
}

static esp_err_t save_blob(const char *key, const void *data, size_t len)
{
    esp_err_t err = nvs_set_blob(s_nvs, key, data, len);
    if (err == ESP_OK) {
        err = nvs_commit(s_nvs);
    }
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "save %s failed: %s", key, esp_err_to_name(err));
    }
    return err;
}

esp_err_t store_init(void)
{
    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_LOGW(TAG, "NVS needs erase (%s)", esp_err_to_name(err));
        ESP_RETURN_ON_ERROR(nvs_flash_erase(), TAG, "erase");
        err = nvs_flash_init();
    }
    ESP_RETURN_ON_ERROR(err, TAG, "nvs init");
    ESP_RETURN_ON_ERROR(nvs_open(NVS_NS, NVS_READWRITE, &s_nvs), TAG, "nvs open");

    s_mtx = xSemaphoreCreateMutex();
    ESP_RETURN_ON_FALSE(s_mtx, ESP_ERR_NO_MEM, TAG, "mutex");

    size_t len = sizeof(s_set);
    if (nvs_get_blob(s_nvs, KEY_SETTINGS, &s_set, &len) != ESP_OK ||
        len != sizeof(s_set) || !store_validate_settings(&s_set)) {
        ESP_LOGW(TAG, "no valid settings - using defaults");
        default_settings(&s_set);
    }

    len = sizeof(s_alarms);
    if (nvs_get_u8(s_nvs, KEY_ACOUNT, &s_count) != ESP_OK || s_count > HOOP_MAX_ALARMS ||
        nvs_get_blob(s_nvs, KEY_ALARMS, s_alarms, &len) != ESP_OK) {
        s_count = 0;
        memset(s_alarms, 0, sizeof(s_alarms));
    }
    for (uint8_t i = 0; i < s_count; i++) {
        if (!store_validate_alarm(&s_alarms[i])) {
            ESP_LOGW(TAG, "alarm %u corrupt - disabled", i);
            memset(&s_alarms[i], 0, sizeof(hoop_alarm_t));
        }
    }

    if (nvs_get_u32(s_nvs, KEY_LASTFIRED, &s_last_fired) != ESP_OK) {
        s_last_fired = 0;
    }
    if (nvs_get_u8(s_nvs, KEY_BALLS, &s_balls) != ESP_OK || s_balls > HOOP_BALL_CAPACITY) {
        s_balls = HOOP_BALL_CAPACITY;
    }

    ESP_LOGI(TAG, "%u alarm(s), volume %u, tone %u, %u shot(s) to dismiss, %u ball(s) loaded",
             s_count, s_set.volume, s_set.tone, s_set.shots_required, s_balls);
    return ESP_OK;
}

void store_get_settings(hoop_settings_t *out)
{
    LOCK();
    *out = s_set;
    UNLOCK();
}

esp_err_t store_set_settings(const hoop_settings_t *in)
{
    if (!store_validate_settings(in)) {
        return ESP_ERR_INVALID_ARG;
    }
    LOCK();
    s_set = *in;
    esp_err_t err = save_blob(KEY_SETTINGS, &s_set, sizeof(s_set));
    UNLOCK();
    return err;
}

uint8_t store_get_alarms(hoop_alarm_t out[HOOP_MAX_ALARMS])
{
    LOCK();
    memcpy(out, s_alarms, sizeof(s_alarms));
    uint8_t n = s_count;
    UNLOCK();
    return n;
}

esp_err_t store_set_alarms(const hoop_alarm_t *in, uint8_t count)
{
    if (count > HOOP_MAX_ALARMS) {
        return ESP_ERR_INVALID_SIZE;
    }
    for (uint8_t i = 0; i < count; i++) {
        if (!store_validate_alarm(&in[i])) {
            return ESP_ERR_INVALID_ARG;
        }
    }
    LOCK();
    memset(s_alarms, 0, sizeof(s_alarms));
    memcpy(s_alarms, in, count * sizeof(hoop_alarm_t));
    s_count = count;
    esp_err_t err = save_blob(KEY_ALARMS, s_alarms, sizeof(s_alarms));
    if (err == ESP_OK) {
        err = nvs_set_u8(s_nvs, KEY_ACOUNT, s_count);
        if (err == ESP_OK) {
            err = nvs_commit(s_nvs);
        }
    }
    UNLOCK();
    return err;
}

esp_err_t store_disable_alarm(uint8_t index)
{
    LOCK();
    esp_err_t err = ESP_ERR_INVALID_ARG;
    if (index < s_count) {
        s_alarms[index].enabled = 0;
        err = save_blob(KEY_ALARMS, s_alarms, sizeof(s_alarms));
    }
    UNLOCK();
    return err;
}

uint32_t store_get_last_fired(void)
{
    return s_last_fired;
}

esp_err_t store_set_last_fired(uint32_t epoch)
{
    LOCK();
    s_last_fired = epoch;
    esp_err_t err = nvs_set_u32(s_nvs, KEY_LASTFIRED, epoch);
    if (err == ESP_OK) {
        err = nvs_commit(s_nvs);
    }
    UNLOCK();
    return err;
}

uint8_t store_get_balls(void)
{
    return s_balls;
}

esp_err_t store_set_balls(uint8_t balls)
{
    if (balls > HOOP_BALL_CAPACITY) {
        balls = HOOP_BALL_CAPACITY;
    }
    LOCK();
    esp_err_t err = ESP_OK;
    if (balls != s_balls) {
        s_balls = balls;
        err = nvs_set_u8(s_nvs, KEY_BALLS, balls);
        if (err == ESP_OK) {
            err = nvs_commit(s_nvs);
        }
    }
    UNLOCK();
    return err;
}

esp_err_t store_factory_reset(void)
{
    LOCK();
    esp_err_t err = nvs_erase_all(s_nvs);
    if (err == ESP_OK) {
        err = nvs_commit(s_nvs);
    }
    default_settings(&s_set);
    memset(s_alarms, 0, sizeof(s_alarms));
    s_count = 0;
    s_last_fired = 0;
    s_balls = HOOP_BALL_CAPACITY;
    UNLOCK();
    ESP_LOGW(TAG, "factory reset");
    return err;
}
