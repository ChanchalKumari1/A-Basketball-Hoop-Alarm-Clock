/*
 * event_log.c - alarm history ring buffer in NVS
 */
#include <string.h>
#include "event_log.h"
#include "nvs.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "esp_check.h"
#include "esp_log.h"

static const char *TAG = "log";

#define NVS_NS   "hooplog"
#define KEY_LOG  "ring"

typedef struct __attribute__((packed)) {
    uint8_t          head;     /* next write position */
    uint8_t          count;
    hoop_log_entry_t e[HOOP_LOG_CAPACITY];
} log_ring_t;

static log_ring_t        s_ring;
static nvs_handle_t      s_nvs;
static SemaphoreHandle_t s_mtx;

static esp_err_t persist(void)
{
    esp_err_t err = nvs_set_blob(s_nvs, KEY_LOG, &s_ring, sizeof(s_ring));
    if (err == ESP_OK) {
        err = nvs_commit(s_nvs);
    }
    return err;
}

esp_err_t event_log_init(void)
{
    s_mtx = xSemaphoreCreateMutex();
    ESP_RETURN_ON_FALSE(s_mtx, ESP_ERR_NO_MEM, TAG, "mutex");
    ESP_RETURN_ON_ERROR(nvs_open(NVS_NS, NVS_READWRITE, &s_nvs), TAG, "open");

    size_t len = sizeof(s_ring);
    if (nvs_get_blob(s_nvs, KEY_LOG, &s_ring, &len) != ESP_OK || len != sizeof(s_ring) ||
        s_ring.head >= HOOP_LOG_CAPACITY || s_ring.count > HOOP_LOG_CAPACITY) {
        memset(&s_ring, 0, sizeof(s_ring));
    }
    ESP_LOGI(TAG, "%u alarm(s) in history", s_ring.count);
    return ESP_OK;
}

esp_err_t event_log_add(const hoop_log_entry_t *e)
{
    xSemaphoreTake(s_mtx, portMAX_DELAY);
    s_ring.e[s_ring.head] = *e;
    s_ring.head = (uint8_t)((s_ring.head + 1) % HOOP_LOG_CAPACITY);
    if (s_ring.count < HOOP_LOG_CAPACITY) {
        s_ring.count++;
    }
    esp_err_t err = persist();
    xSemaphoreGive(s_mtx);
    return err;
}

uint8_t event_log_read(hoop_log_entry_t *out, uint8_t max)
{
    xSemaphoreTake(s_mtx, portMAX_DELAY);
    uint8_t n = s_ring.count < max ? s_ring.count : max;
    for (uint8_t i = 0; i < n; i++) {
        int idx = (s_ring.head - 1 - i + HOOP_LOG_CAPACITY) % HOOP_LOG_CAPACITY;
        out[i] = s_ring.e[idx];
    }
    xSemaphoreGive(s_mtx);
    return n;
}

esp_err_t event_log_clear(void)
{
    xSemaphoreTake(s_mtx, portMAX_DELAY);
    memset(&s_ring, 0, sizeof(s_ring));
    esp_err_t err = persist();
    xSemaphoreGive(s_mtx);
    return err;
}
