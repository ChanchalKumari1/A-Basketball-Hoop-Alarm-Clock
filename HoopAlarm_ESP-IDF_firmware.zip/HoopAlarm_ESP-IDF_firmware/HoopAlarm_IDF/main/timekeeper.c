/*
 * timekeeper.c - GPTimer 1 Hz tick phase-locked to the DS3231
 */
#include "timekeeper.h"
#include "ds3231.h"
#include "time_util.h"
#include "app_config.h"
#include "driver/gptimer.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "esp_timer.h"
#include "esp_attr.h"
#include "esp_check.h"
#include "esp_log.h"

static const char *TAG = "timekeeper";

static gptimer_handle_t  s_timer;
static volatile uint32_t s_epoch;
static volatile int16_t  s_temp = INT16_MIN;
static bool              s_running;
static tk_tick_cb_t      s_cb;
static SemaphoreHandle_t s_lock;
static TaskHandle_t      s_sync_task;

static bool IRAM_ATTR on_timer_alarm(gptimer_handle_t timer,
                                     const gptimer_alarm_event_data_t *edata,
                                     void *user_ctx)
{
    uint32_t ep = s_epoch + 1;
    s_epoch = ep;
    BaseType_t woken = pdFALSE;
    if (s_cb) {
        s_cb(ep, &woken);
    }
    return woken == pdTRUE;
}

/* Restart the 1 s period so that its next interrupt lands exactly 1 s from now. */
static void restart_tick_at(uint32_t epoch)
{
    if (s_running) {
        gptimer_stop(s_timer);
    }
    gptimer_set_raw_count(s_timer, 0);
    s_epoch = epoch;
    gptimer_start(s_timer);
    s_running = true;
}

/* Wait for the DS3231 seconds register to roll over, then start the tick on that edge. */
static esp_err_t align_to_rtc(void)
{
    uint32_t first, cur;
    ESP_RETURN_ON_ERROR(ds3231_get_epoch(&first), TAG, "read rtc");
    int64_t t0 = esp_timer_get_time();
    do {
        vTaskDelay(1);   /* 1 ms at CONFIG_FREERTOS_HZ=1000 */
        if (ds3231_get_epoch(&cur) != ESP_OK) {
            return ESP_FAIL;
        }
        if (esp_timer_get_time() - t0 > 1500000) {
            return ESP_ERR_TIMEOUT;
        }
    } while (cur == first);
    restart_tick_at(cur);
    return ESP_OK;
}

static void resync(void)
{
    if (!ds3231_present()) {
        return;
    }
    xSemaphoreTake(s_lock, portMAX_DELAY);
    uint32_t rtc;
    if (ds3231_get_epoch(&rtc) == ESP_OK) {
        int32_t diff = (int32_t)(rtc - s_epoch);
        if (diff != 0) {
            ESP_LOGW(TAG, "tick drifted %ld s from DS3231 - realigning", (long)diff);
            if (align_to_rtc() != ESP_OK) {
                restart_tick_at(rtc);
            }
        }
    } else {
        ESP_LOGW(TAG, "DS3231 read failed during resync");
    }
    xSemaphoreGive(s_lock);
}

static void timesync_task(void *arg)
{
    uint32_t minutes = 0;
    uint32_t last_daily = UINT32_MAX;

    for (;;) {
        bool forced = ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(60000)) > 0;

        int16_t t;
        if (ds3231_get_temperature(&t) == ESP_OK) {
            s_temp = t;
        }

        minutes++;
        uint32_t now = s_epoch;
        uint32_t day = now / 86400u;
        uint32_t sod = now % 86400u;
        bool daily = (sod >= 3u * 3600u && sod < 3u * 3600u + 180u && day != last_daily);

        if (forced || daily || minutes >= CONFIG_HOOP_RTC_RESYNC_MIN) {
            minutes = 0;
            if (daily) {
                last_daily = day;
                ESP_LOGI(TAG, "daily DS3231 resync");
            }
            resync();
        }
    }
}

esp_err_t timekeeper_init(tk_tick_cb_t cb)
{
    s_cb = cb;
    s_lock = xSemaphoreCreateMutex();
    ESP_RETURN_ON_FALSE(s_lock, ESP_ERR_NO_MEM, TAG, "mutex");

    gptimer_config_t cfg = {
        .clk_src = GPTIMER_CLK_SRC_DEFAULT,
        .direction = GPTIMER_COUNT_UP,
        .resolution_hz = 1000000,          /* 1 us resolution */
    };
    ESP_RETURN_ON_ERROR(gptimer_new_timer(&cfg, &s_timer), TAG, "new timer");

    gptimer_alarm_config_t alarm = {
        .reload_count = 0,
        .alarm_count = 1000000,            /* 1 s */
        .flags.auto_reload_on_alarm = true,
    };
    ESP_RETURN_ON_ERROR(gptimer_set_alarm_action(s_timer, &alarm), TAG, "alarm");

    gptimer_event_callbacks_t cbs = { .on_alarm = on_timer_alarm };
    /* interrupt is allocated on the calling core -> caller runs on CORE_REALTIME */
    ESP_RETURN_ON_ERROR(gptimer_register_event_callbacks(s_timer, &cbs, NULL), TAG, "cb");
    ESP_RETURN_ON_ERROR(gptimer_enable(s_timer), TAG, "enable");

    esp_err_t err = ESP_ERR_INVALID_STATE;
    if (ds3231_present()) {
        err = align_to_rtc();
        if (err != ESP_OK) {
            uint32_t rtc = 0;
            ds3231_get_epoch(&rtc);
            restart_tick_at(rtc);
        }
    } else {
        restart_tick_at(0);   /* no RTC: run free until the app sets the time */
    }

    tu_datetime_t dt;
    tu_split_epoch(s_epoch, &dt);
    ESP_LOGI(TAG, "time %04u-%02u-%02u %02u:%02u:%02u%s", dt.year, dt.month, dt.day,
             dt.hour, dt.minute, dt.second, timekeeper_valid() ? "" : " (NOT SET)");

    xTaskCreatePinnedToCore(timesync_task, "timesync", 3072, NULL, PRIO_TIMESYNC,
                            &s_sync_task, CORE_REALTIME);
    return err;
}

uint32_t timekeeper_now(void)
{
    return s_epoch;
}

bool timekeeper_valid(void)
{
    return s_epoch >= TU_EPOCH_2024 && !ds3231_lost_power();
}

esp_err_t timekeeper_set_time(uint32_t epoch)
{
    if (epoch < TU_EPOCH_2000) {
        return ESP_ERR_INVALID_ARG;
    }
    xSemaphoreTake(s_lock, portMAX_DELAY);
    esp_err_t err = ESP_OK;
    if (ds3231_present()) {
        err = ds3231_set_epoch(epoch);
    }
    /* Writing the DS3231 seconds register resets its countdown chain, so the RTC's next
     * second edge is exactly 1 s from now - restart our tick at the same moment. */
    restart_tick_at(epoch);
    xSemaphoreGive(s_lock);
    ESP_LOGI(TAG, "time set to %lu", (unsigned long)epoch);
    return err;
}

void timekeeper_request_resync(void)
{
    if (s_sync_task) {
        xTaskNotifyGive(s_sync_task);
    }
}

int16_t timekeeper_temperature(void)
{
    return s_temp;
}
