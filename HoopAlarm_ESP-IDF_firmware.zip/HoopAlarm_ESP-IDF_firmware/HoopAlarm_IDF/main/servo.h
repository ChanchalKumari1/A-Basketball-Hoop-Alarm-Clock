/*
 * servo.h - SG90 micro servo that releases one ball from the cradle.
 * Runs asynchronously in its own task so the alarm engine never blocks.
 * Servo power is switched by a MOSFET (PIN_SERVO_PWR) only while moving, and
 * the PWM is stopped afterwards, to avoid supply spikes and jitter.
 */
#pragma once

#include <stdbool.h>
#include "esp_err.h"

esp_err_t servo_init(void);
bool      servo_request_drop(void);   /* false if busy or no servo fitted */
bool      servo_busy(void);
void      servo_power_off(void);      /* before deep sleep */
