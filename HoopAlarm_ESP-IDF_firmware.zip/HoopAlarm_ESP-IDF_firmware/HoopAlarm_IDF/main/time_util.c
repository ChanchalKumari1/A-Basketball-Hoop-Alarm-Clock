#include "time_util.h"

/* Howard Hinnant's civil-date algorithms (public domain). */
static int32_t days_from_civil(int32_t y, uint32_t m, uint32_t d)
{
    y -= (m <= 2);
    const int32_t  era = (y >= 0 ? y : y - 399) / 400;
    const uint32_t yoe = (uint32_t)(y - era * 400);
    const uint32_t doy = (153u * (m > 2 ? m - 3 : m + 9) + 2u) / 5u + d - 1u;
    const uint32_t doe = yoe * 365u + yoe / 4u - yoe / 100u + doy;
    return era * 146097 + (int32_t)doe - 719468;
}

uint32_t tu_make_epoch(int year, int month, int day, int hour, int minute, int second)
{
    int32_t days = days_from_civil(year, (uint32_t)month, (uint32_t)day);
    return (uint32_t)days * 86400u + (uint32_t)hour * 3600u +
           (uint32_t)minute * 60u + (uint32_t)second;
}

void tu_split_epoch(uint32_t epoch, tu_datetime_t *out)
{
    int32_t  z   = (int32_t)(epoch / 86400u);
    uint32_t sod = epoch % 86400u;

    out->wday   = (uint8_t)((z + 4) % 7);
    out->hour   = (uint8_t)(sod / 3600u);
    out->minute = (uint8_t)((sod / 60u) % 60u);
    out->second = (uint8_t)(sod % 60u);

    z += 719468;
    const int32_t  era = (z >= 0 ? z : z - 146096) / 146097;
    const uint32_t doe = (uint32_t)(z - era * 146097);
    const uint32_t yoe = (doe - doe / 1460u + doe / 36524u - doe / 146096u) / 365u;
    int32_t        y   = (int32_t)yoe + era * 400;
    const uint32_t doy = doe - (365u * yoe + yoe / 4u - yoe / 100u);
    const uint32_t mp  = (5u * doy + 2u) / 153u;
    const uint32_t d   = doy - (153u * mp + 2u) / 5u + 1u;
    const uint32_t m   = mp < 10 ? mp + 3 : mp - 9;
    y += (m <= 2);

    out->year  = (uint16_t)y;
    out->month = (uint8_t)m;
    out->day   = (uint8_t)d;
}
