/*
 * ui.c - display content
 */
#include <stdio.h>
#include <string.h>
#include "ui.h"
#include "app_config.h"
#include "display.h"
#include "alarm_engine.h"
#include "settings_store.h"
#include "ota_update.h"
#include "power.h"
#include "time_util.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_timer.h"

#define NO_PASSKEY UINT32_MAX

static portMUX_TYPE      s_mux = portMUX_INITIALIZER_UNLOCKED;
static volatile uint32_t s_passkey = NO_PASSKEY;
static char              s_msg[16];
static int64_t           s_msg_until_us;

void ui_show_passkey(uint32_t passkey) { s_passkey = passkey; }
void ui_clear_passkey(void)            { s_passkey = NO_PASSKEY; }

void ui_show_message(const char *text, uint32_t ms)
{
    taskENTER_CRITICAL(&s_mux);
    strlcpy(s_msg, text, sizeof(s_msg));
    s_msg_until_us = esp_timer_get_time() + (int64_t)ms * 1000;
    taskEXIT_CRITICAL(&s_mux);
}

#if HOOP_HAS_DISPLAY

static bool in_night(const hoop_settings_t *s, uint8_t hour)
{
    if (s->night_start_hour == s->night_end_hour) {
        return false;
    }
    if (s->night_start_hour < s->night_end_hour) {
        return hour >= s->night_start_hour && hour < s->night_end_hour;
    }
    return hour >= s->night_start_hour || hour < s->night_end_hour;   /* wraps midnight */
}

static void render_passkey(uint32_t pk, bool second_half)
{
    char buf[12];
#if HOOP_DISPLAY_DIGITS >= 8
    snprintf(buf, sizeof(buf), "P %06lu", (unsigned long)pk);
#elif HOOP_DISPLAY_DIGITS >= 6
    snprintf(buf, sizeof(buf), "%06lu", (unsigned long)pk);
#else
    char six[8];
    snprintf(six, sizeof(six), "%06lu", (unsigned long)pk);
    if (second_half) {
        snprintf(buf, sizeof(buf), "  %c%c", six[4], six[5]);
    } else {
        snprintf(buf, sizeof(buf), "%c%c%c%c", six[0], six[1], six[2], six[3]);
    }
#endif
    (void)second_half;
    display_print(buf);
}

static void render_clock(const hoop_status_t *st, const hoop_settings_t *set, int64_t now_ms)
{
    char    c[8];
    uint8_t dp = 0;
    memset(c, ' ', sizeof(c));

    bool blink_on = (now_ms % 1000) < 500;
    bool ringing = st->state == HOOP_STATE_RINGING;

    if (!(st->flags & ST_F_TIME_VALID)) {
        /* time never set (or DS3231 coin cell died): flashing dashes */
        if (blink_on) {
            memcpy(c, "--------", sizeof(c));
        }
        if (HOOP_DISPLAY_DIGITS >= 8) {
            memcpy(&c[4], "SEt ", 4);
        }
        display_render(c, 0);
        return;
    }

    tu_datetime_t dt;
    tu_split_epoch(st->now_epoch, &dt);
    uint8_t h = dt.hour;
    bool pm = h >= 12;
    if (!set->use_24h) {
        h %= 12;
        if (h == 0) {
            h = 12;
        }
    }

    bool show_time = !ringing || blink_on;   /* flash during an alarm */
    if (show_time) {
        c[0] = (h >= 10 || set->use_24h) ? (char)('0' + h / 10) : ' ';
        c[1] = (char)('0' + h % 10);
        c[2] = (char)('0' + dt.minute / 10);
        c[3] = (char)('0' + dt.minute % 10);
#if HOOP_DISPLAY_DIGITS >= 6
        c[4] = (char)('0' + dt.second / 10);
        c[5] = (char)('0' + dt.second % 10);
#endif
        if (blink_on || ringing) {
            dp |= (uint8_t)(1u << CONFIG_HOOP_DISPLAY_COLON_DIGIT);
        }
        if (!set->use_24h && pm) {
            dp |= (uint8_t)(1u << 3);                      /* PM dot after the minutes */
        }
    }

#if HOOP_DISPLAY_DIGITS >= 8
    if (ringing) {
        if (st->flags & ST_F_OUT_OF_BALLS) {
            c[6] = '-';
            c[7] = '-';
        } else {
            uint8_t left = st->shots_required > st->shots_made ? st->shots_required - st->shots_made : 0;
            c[6] = 'S';
            c[7] = (char)('0' + (left > 9 ? 9 : left));
        }
    } else if (st->flags & ST_F_BATT_LOW) {
        c[6] = 'L';
        c[7] = 'o';
    } else if (st->flags & ST_F_OUT_OF_BALLS) {
        c[6] = 'b';
        c[7] = '0';
    } else if (st->flags2 & ST_F2_ALARM_ARMED) {
        c[6] = 'A';
        c[7] = 'L';
    }
#endif
    display_render(c, dp);
}

static void ui_task(void *arg)
{
    for (;;) {
        vTaskDelay(pdMS_TO_TICKS(100));
        int64_t now_us = esp_timer_get_time();
        int64_t now_ms = now_us / 1000;

        hoop_status_t st;
        hoop_settings_t set;
        alarm_engine_get_status(&st);
        store_get_settings(&set);

        /* brightness: full while ringing, dimmed in the night window */
        tu_datetime_t dt;
        tu_split_epoch(st.now_epoch, &dt);
        uint8_t bri = set.brightness;
        if (st.state != HOOP_STATE_RINGING && (st.flags & ST_F_TIME_VALID) && in_night(&set, dt.hour)) {
            bri = set.night_brightness;
        }
        if (st.state == HOOP_STATE_RINGING || s_passkey != NO_PASSKEY) {
            bri = 100;
        }
        display_set_brightness(bri);

        char msg[16] = {0};
        taskENTER_CRITICAL(&s_mux);
        if (now_us < s_msg_until_us) {
            memcpy(msg, s_msg, sizeof(msg));
        }
        taskEXIT_CRITICAL(&s_mux);

        if (ota_update_in_progress()) {
            char buf[12];
            snprintf(buf, sizeof(buf), "OtA %3u", ota_update_progress_pct());
            display_print(buf);
        } else if (s_passkey != NO_PASSKEY) {
            render_passkey(s_passkey, (now_ms / 1000) % 2);
        } else if (msg[0]) {
            display_print(msg);
        } else {
            render_clock(&st, &set, now_ms);
        }
    }
}

void ui_start(void)
{
    ui_show_message("HOOP", 1200);
    xTaskCreatePinnedToCore(ui_task, "ui", 3072, NULL, PRIO_UI, NULL, CORE_REALTIME);
}

#else

void ui_start(void) { }

#endif
