/*
 * power.c - battery, button and deep sleep management (task on core 0)
 */
#include "power.h"
#include "app_config.h"
#include "alarm_engine.h"
#include "ble_service.h"
#include "ota_update.h"
#include "buzzer.h"
#include "servo.h"
#include "shot_sensor.h"
#include "display.h"
#include "ui.h"
#include "ds3231.h"
#include "driver/gpio.h"
#include "driver/rtc_io.h"
#include "esp_adc/adc_oneshot.h"
#include "esp_adc/adc_cali.h"
#include "esp_adc/adc_cali_scheme.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_timer.h"
#include "esp_check.h"
#include "esp_log.h"

static const char *TAG = "power";

#define POLL_MS              20
#define BATT_PERIOD_MS       30000
#define SLEEP_IDLE_US        ((int64_t)CONFIG_HOOP_IDLE_SLEEP_S * 1000000)
#define SLEEP_IDLE_SHORT_US  (4 * 1000000LL)      /* after a backup-timer wake */
#define ALARM_IMMINENT_S     60
#define BACKUP_WAKE_MAX_S    (6 * 3600)

static esp_sleep_wakeup_cause_t s_wake;
static volatile int64_t         s_last_activity_us;
static int64_t                  s_idle_us = SLEEP_IDLE_US;

static volatile uint16_t        s_batt_mv;
static volatile uint8_t         s_batt_pct;
static volatile bool            s_charging;

static adc_oneshot_unit_handle_t s_adc;
static adc_cali_handle_t         s_cali;
static adc_channel_t             s_adc_ch;
static bool                      s_adc_ok;

/* ---------------- battery ---------------- */

static uint8_t lipo_pct(uint16_t mv)
{
    static const struct { uint16_t mv; uint8_t pct; } curve[] = {
        {4200, 100}, {4100, 90}, {4000, 78}, {3900, 63}, {3800, 47},
        {3700, 30}, {3600, 15}, {3500, 6}, {3400, 2}, {3300, 0},
    };
    if (mv >= curve[0].mv) {
        return 100;
    }
    for (size_t i = 1; i < sizeof(curve) / sizeof(curve[0]); i++) {
        if (mv >= curve[i].mv) {
            uint32_t span = curve[i - 1].mv - curve[i].mv;
            return (uint8_t)(curve[i].pct + (curve[i - 1].pct - curve[i].pct) * (mv - curve[i].mv) / span);
        }
    }
    return 0;
}

static void battery_init(void)
{
#if HOOP_ON_BATTERY
    if (PIN_BATT_ADC < 0) {
        return;
    }
    adc_unit_t unit;
    if (adc_oneshot_io_to_channel(PIN_BATT_ADC, &unit, &s_adc_ch) != ESP_OK || unit != ADC_UNIT_1) {
        ESP_LOGE(TAG, "GPIO%d is not an ADC1 pin (ADC2 is unusable with BLE)", PIN_BATT_ADC);
        return;
    }
    adc_oneshot_unit_init_cfg_t ucfg = { .unit_id = ADC_UNIT_1 };
    if (adc_oneshot_new_unit(&ucfg, &s_adc) != ESP_OK) {
        return;
    }
    adc_oneshot_chan_cfg_t ccfg = { .atten = ADC_ATTEN_DB_12, .bitwidth = ADC_BITWIDTH_DEFAULT };
    adc_oneshot_config_channel(s_adc, s_adc_ch, &ccfg);

#if ADC_CALI_SCHEME_LINE_FITTING_SUPPORTED
    adc_cali_line_fitting_config_t cal = {
        .unit_id = ADC_UNIT_1,
        .atten = ADC_ATTEN_DB_12,
        .bitwidth = ADC_BITWIDTH_DEFAULT,
    };
    if (adc_cali_create_scheme_line_fitting(&cal, &s_cali) != ESP_OK) {
        s_cali = NULL;
    }
#endif
    s_adc_ok = true;

    if (PIN_CHARGE_STAT >= 0) {
        gpio_config_t io = {
            .pin_bit_mask = 1ULL << PIN_CHARGE_STAT,
            .mode = GPIO_MODE_INPUT,
            .pull_up_en = (PIN_CHARGE_STAT < 34) ? GPIO_PULLUP_ENABLE : GPIO_PULLUP_DISABLE,
        };
        gpio_config(&io);   /* GPIO34-39: fit an external pull-up to 3V3 */
    }
#endif
}

static void battery_sample(void)
{
    if (!s_adc_ok) {
        return;
    }
    int raw_sum = 0, mv_sum = 0, n = 0;
    for (int i = 0; i < 16; i++) {
        int raw;
        if (adc_oneshot_read(s_adc, s_adc_ch, &raw) == ESP_OK) {
            raw_sum += raw;
            n++;
        }
    }
    if (n == 0) {
        return;
    }
    int raw = raw_sum / n;
    if (s_cali) {
        adc_cali_raw_to_voltage(s_cali, raw, &mv_sum);
    } else {
        mv_sum = raw * 3300 / 4095;   /* rough fallback */
    }
    uint32_t vbat = (uint32_t)mv_sum * CONFIG_HOOP_BATT_DIVIDER_X100 / 100u;
    s_batt_mv  = (uint16_t)vbat;
    s_batt_pct = lipo_pct((uint16_t)vbat);
    s_charging = (PIN_CHARGE_STAT >= 0) && gpio_get_level(PIN_CHARGE_STAT) == 0;
    ESP_LOGD(TAG, "battery %u mV (%u%%)%s", s_batt_mv, s_batt_pct, s_charging ? " charging" : "");
}

uint16_t power_batt_mv(void)  { return s_batt_mv; }
uint8_t  power_batt_pct(void) { return s_batt_pct; }
bool     power_charging(void) { return s_charging; }
bool     power_batt_low(void)
{
    return HOOP_ON_BATTERY && s_batt_mv && s_batt_mv < CONFIG_HOOP_BATT_LOW_MV && !s_charging;
}

/* ---------------- deep sleep ---------------- */

static void enter_deep_sleep(uint32_t secs_to_alarm)
{
    /* make sure the DS3231 INT line is released and armed for the next alarm */
    bool stale = false;
    ds3231_check_and_clear_alarm1(&stale);

    ESP_LOGI(TAG, "deep sleep (next alarm in %lu s)", (unsigned long)secs_to_alarm);
    ble_service_stop_advertising();
    buzzer_stop();
    shot_sensor_arm(false);
    servo_power_off();
    display_off();
    vTaskDelay(pdMS_TO_TICKS(50));

    /* RTC peripherals stay powered so the pull-ups hold during sleep */
    esp_sleep_pd_config(ESP_PD_DOMAIN_RTC_PERIPH, ESP_PD_OPTION_ON);

    if (rtc_gpio_is_valid_gpio(PIN_RTC_INT)) {
        rtc_gpio_pullup_en(PIN_RTC_INT);
        rtc_gpio_pulldown_dis(PIN_RTC_INT);
        esp_sleep_enable_ext0_wakeup(PIN_RTC_INT, 0);       /* DS3231 INT is active low */
    } else {
        ESP_LOGE(TAG, "GPIO%d cannot wake from deep sleep - using timer only", PIN_RTC_INT);
    }
    if (rtc_gpio_is_valid_gpio(PIN_BUTTON)) {
        rtc_gpio_pullup_en(PIN_BUTTON);
        rtc_gpio_pulldown_dis(PIN_BUTTON);
        esp_sleep_enable_ext1_wakeup(1ULL << PIN_BUTTON, ESP_EXT1_WAKEUP_ALL_LOW);
    }

    /* Backup timer: the ESP32's own RTC clock drifts several %, so always wake EARLY,
     * re-check against the DS3231 and sleep again; the DS3231 INT does the precise wake. */
    if (secs_to_alarm) {
        uint32_t s = secs_to_alarm > BACKUP_WAKE_MAX_S ? BACKUP_WAKE_MAX_S : secs_to_alarm;
        s = s * 90u / 100u;
        if (s < 30) {
            s = 30;
        }
        esp_sleep_enable_timer_wakeup((uint64_t)s * 1000000ULL);
    }

    /* keep the IR emitter and servo supply switched off while asleep */
    if (PIN_IR_EMITTER_EN >= 0) {
        gpio_set_level(PIN_IR_EMITTER_EN, 0);
        gpio_hold_en(PIN_IR_EMITTER_EN);
    }
    if (PIN_SERVO_PWR >= 0) {
        gpio_set_level(PIN_SERVO_PWR, 0);
        gpio_hold_en(PIN_SERVO_PWR);
    }
    gpio_deep_sleep_hold_en();

    esp_deep_sleep_start();
}

static void check_sleep(int64_t now)
{
#if HOOP_ON_BATTERY
    if (alarm_engine_is_busy() || ble_service_is_connected() || ble_service_is_advertising() ||
        ota_update_in_progress() || buzzer_is_active() || servo_busy() ||
        gpio_get_level(PIN_BUTTON) == 0) {
        return;
    }
    if (now - s_last_activity_us < s_idle_us) {
        return;
    }
    uint32_t secs = alarm_engine_seconds_to_next();
    if (secs != 0 && secs < ALARM_IMMINENT_S) {
        return;   /* alarm is about to go off - stay awake */
    }
    enter_deep_sleep(secs);
#else
    (void)now;
#endif
}

/* ---------------- button ---------------- */

static void handle_button(int64_t now)
{
    static bool    down;
    static int64_t t0;
    static int     stage;
    bool pressed = gpio_get_level(PIN_BUTTON) == 0;

    if (pressed && !down) {
        down = true;
        t0 = now;
        stage = 0;
        power_note_activity();
    } else if (pressed && down) {
        int64_t held_ms = (now - t0) / 1000;
        if (held_ms >= HOOP_BTN_CLEAR_BONDS_MS && stage < 2) {
            stage = 2;
            ble_service_clear_bonds();
            ui_show_message("CLr bond", 2500);
            buzzer_jingle(JINGLE_ERROR);
        } else if (held_ms >= HOOP_BTN_RELOAD_MS && stage < 1) {
            stage = 1;
            alarm_engine_post(EV_CMD_RELOAD, HOOP_BALL_CAPACITY, 0, 0);
            ui_show_message("bALLS", 1500);
            buzzer_jingle(JINGLE_ACK);
        }
    } else if (!pressed && down) {
        down = false;
        int64_t held_ms = (now - t0) / 1000;
        if (stage == 0 && held_ms >= 40) {
            /* short press: BLE setup window + allow a new phone to pair */
            ble_service_open_pairing(HOOP_PAIRING_WINDOW_S);
            ble_service_start_advertising(CONFIG_HOOP_BLE_ADV_WINDOW_S ? CONFIG_HOOP_BLE_ADV_WINDOW_S : 0);
            ui_show_message("bLE", 1500);
            buzzer_jingle(JINGLE_BLE);
        }
        power_note_activity();
    }
}

static void power_task(void *arg)
{
    int64_t last_batt = 0;
    for (;;) {
        int64_t now = esp_timer_get_time();
        handle_button(now);
        if (now - last_batt >= (int64_t)BATT_PERIOD_MS * 1000) {
            last_batt = now;
            battery_sample();
        }
        check_sleep(now);
        vTaskDelay(pdMS_TO_TICKS(POLL_MS));
    }
}

/* ---------------- public ---------------- */

void power_early_init(void)
{
    /* undo deep-sleep pin holds and give RTC IO pins back to the digital GPIO matrix */
    gpio_deep_sleep_hold_dis();
    if (PIN_IR_EMITTER_EN >= 0) {
        gpio_hold_dis(PIN_IR_EMITTER_EN);
    }
    if (PIN_SERVO_PWR >= 0) {
        gpio_hold_dis(PIN_SERVO_PWR);
    }
    if (rtc_gpio_is_valid_gpio(PIN_RTC_INT)) {
        rtc_gpio_deinit(PIN_RTC_INT);
    }
    if (rtc_gpio_is_valid_gpio(PIN_BUTTON)) {
        rtc_gpio_deinit(PIN_BUTTON);
    }
}

esp_err_t power_init(esp_sleep_wakeup_cause_t wake)
{
    s_wake = wake;
    s_last_activity_us = esp_timer_get_time();
    if (wake == ESP_SLEEP_WAKEUP_TIMER) {
        s_idle_us = SLEEP_IDLE_SHORT_US;   /* backup wake: check, then straight back to sleep */
    }

    gpio_config_t btn = {
        .pin_bit_mask = 1ULL << PIN_BUTTON,
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
    };
    ESP_RETURN_ON_ERROR(gpio_config(&btn), TAG, "button");

    battery_init();
    battery_sample();
    if (power_batt_low()) {
        ESP_LOGW(TAG, "battery low: %u mV", s_batt_mv);
    }
    return ESP_OK;
}

void power_start(void)
{
    /* BLE advertising policy at boot */
    bool advertise;
    if (!HOOP_ON_BATTERY) {
        advertise = true;
    } else {
        /* cold boot or button wake -> user is here; alarm/backup wake -> stay quiet */
        advertise = (s_wake != ESP_SLEEP_WAKEUP_EXT0 && s_wake != ESP_SLEEP_WAKEUP_TIMER);
    }
    if (advertise) {
        ble_service_start_advertising(CONFIG_HOOP_BLE_ADV_WINDOW_S);
    }
    if (s_wake == ESP_SLEEP_WAKEUP_EXT1) {
        ble_service_open_pairing(HOOP_PAIRING_WINDOW_S);   /* woken by button press */
    }

    xTaskCreatePinnedToCore(power_task, "power", 3584, NULL, PRIO_POWER, NULL, CORE_COMMS);
}

void power_note_activity(void)
{
    s_last_activity_us = esp_timer_get_time();
    s_idle_us = SLEEP_IDLE_US;
}
