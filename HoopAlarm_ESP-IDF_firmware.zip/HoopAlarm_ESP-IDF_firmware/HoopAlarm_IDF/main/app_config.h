/*
 * app_config.h - board configuration derived from menuconfig (Kconfig.projbuild)
 *
 * Default pin map (ESP32-WROOM-32) - change with `idf.py menuconfig`:
 *
 *   DS3231 SDA ........ GPIO21     DS3231 SCL ........ GPIO22
 *   DS3231 INT/SQW .... GPIO33 (RTC IO, deep-sleep wake, ext0)
 *   IR receiver ....... GPIO32     IR emitter enable . GPIO27
 *   Buzzer (NPN) ...... GPIO25     Servo signal ...... GPIO26
 *   Servo power FET ... GPIO4      Button ............ GPIO14 (RTC IO, ext1)
 *   Display SER ....... GPIO23     Display SRCK ...... GPIO18
 *   Display RCK ....... GPIO19     Display /OE (PWM) . GPIO17
 *   Battery ADC ....... GPIO36     TP4056 CHRG ....... GPIO39
 */
#pragma once

#include "sdkconfig.h"
#include "driver/ledc.h"

/* ---------- feature switches (Kconfig bools -> 0/1) ---------- */
#ifdef CONFIG_HOOP_POWER_BATTERY
#define HOOP_ON_BATTERY 1
#else
#define HOOP_ON_BATTERY 0
#endif

#ifdef CONFIG_HOOP_HAS_SERVO
#define HOOP_HAS_SERVO 1
#else
#define HOOP_HAS_SERVO 0
#endif

#ifdef CONFIG_HOOP_HAS_DISPLAY
#define HOOP_HAS_DISPLAY 1
#else
#define HOOP_HAS_DISPLAY 0
#endif

#ifdef CONFIG_HOOP_IR_ACTIVE_LOW
#define HOOP_IR_ACTIVE_LOW 1
#else
#define HOOP_IR_ACTIVE_LOW 0
#endif

#ifdef CONFIG_HOOP_DISPLAY_INVERT
#define HOOP_DISPLAY_INVERT 1
#else
#define HOOP_DISPLAY_INVERT 0
#endif

#ifdef CONFIG_HOOP_DISPLAY_CHAIN_REVERSED
#define HOOP_DISPLAY_CHAIN_REVERSED 1
#else
#define HOOP_DISPLAY_CHAIN_REVERSED 0
#endif

#ifdef CONFIG_HOOP_BLE_PAIRING_NEEDS_BUTTON
#define HOOP_PAIRING_NEEDS_BUTTON 1
#else
#define HOOP_PAIRING_NEEDS_BUTTON 0
#endif

#ifdef CONFIG_HOOP_ALLOW_APP_STOP
#define HOOP_ALLOW_APP_STOP 1
#else
#define HOOP_ALLOW_APP_STOP 0
#endif

/* ---------- pins ---------- */
#define PIN_I2C_SDA         CONFIG_HOOP_PIN_I2C_SDA
#define PIN_I2C_SCL         CONFIG_HOOP_PIN_I2C_SCL
#define PIN_RTC_INT         CONFIG_HOOP_PIN_RTC_INT
#define PIN_IR_RX           CONFIG_HOOP_PIN_IR_RX
#define PIN_IR_EMITTER_EN   CONFIG_HOOP_PIN_IR_EMITTER_EN
#define PIN_BUZZER          CONFIG_HOOP_PIN_BUZZER
#define PIN_SERVO           CONFIG_HOOP_PIN_SERVO
#define PIN_SERVO_PWR       CONFIG_HOOP_PIN_SERVO_PWR
#define PIN_BUTTON          CONFIG_HOOP_PIN_BUTTON
#define PIN_DISP_MOSI       CONFIG_HOOP_PIN_DISP_MOSI
#define PIN_DISP_SCLK       CONFIG_HOOP_PIN_DISP_SCLK
#define PIN_DISP_LATCH      CONFIG_HOOP_PIN_DISP_LATCH
#define PIN_DISP_OE         CONFIG_HOOP_PIN_DISP_OE
#define PIN_BATT_ADC        CONFIG_HOOP_PIN_BATT_ADC
#define PIN_CHARGE_STAT     CONFIG_HOOP_PIN_CHARGE_STAT

/* ---------- LEDC (PWM) allocation ---------- */
#define HOOP_LEDC_MODE          LEDC_LOW_SPEED_MODE
#define BUZZER_LEDC_TIMER       LEDC_TIMER_0
#define BUZZER_LEDC_CHANNEL     LEDC_CHANNEL_0
#define SERVO_LEDC_TIMER        LEDC_TIMER_1
#define SERVO_LEDC_CHANNEL      LEDC_CHANNEL_1
#define DISP_LEDC_TIMER         LEDC_TIMER_2
#define DISP_LEDC_CHANNEL       LEDC_CHANNEL_2

/* ---------- dual-core layout ----------
 * Core 1 (APP CPU): tick timer ISR, DS3231 INT ISR, IR sensor ISR, alarm engine,
 *                   buzzer, servo, display.  Nothing radio-related runs here.
 * Core 0 (PRO CPU): BLE controller + NimBLE host, OTA writes, power/button task.
 */
#define CORE_REALTIME           1
#define CORE_COMMS              0

#define PRIO_ENGINE             (configMAX_PRIORITIES - 2)
#define PRIO_SHOT               (configMAX_PRIORITIES - 3)
#define PRIO_BUZZER             (configMAX_PRIORITIES - 4)
#define PRIO_SERVO              (configMAX_PRIORITIES - 4)
#define PRIO_TIMESYNC           5
#define PRIO_UI                 3
#define PRIO_POWER              4

/* ---------- behaviour constants ---------- */
#define HOOP_BALL_CAPACITY          CONFIG_HOOP_BALL_CAPACITY
#define HOOP_DISPLAY_DIGITS         CONFIG_HOOP_DISPLAY_DIGITS
#define HOOP_ALARM_GRACE_S          CONFIG_HOOP_ALARM_GRACE_S
#define HOOP_RAMP_STEP_MS           10000   /* +1 volume step every 10 s once ramping */
#define HOOP_AFTER_MADE_DELAY_MS    1500    /* pause before next ball when >1 shot needed */
#define HOOP_SERVO_CYCLE_MS         900     /* release + return + settle */
#define HOOP_PAIRING_WINDOW_S       60
#define HOOP_BTN_RELOAD_MS          4000    /* hold: balls reloaded */
#define HOOP_BTN_CLEAR_BONDS_MS     10000   /* hold: forget all phones */
