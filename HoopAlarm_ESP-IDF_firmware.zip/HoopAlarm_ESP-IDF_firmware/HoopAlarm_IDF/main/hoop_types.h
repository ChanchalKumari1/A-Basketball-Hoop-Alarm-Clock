/*
 * hoop_types.h - data structures shared between firmware modules and the
 * BLE protocol (all multi-byte fields little-endian, structs packed).
 * See docs/BLE_PROTOCOL.md - keep both in sync.
 */
#pragma once

#include <stdint.h>
#include <stdbool.h>

#define HOOP_FW_MAJOR       1
#define HOOP_FW_MINOR       0
#define HOOP_FW_PATCH       0

#define HOOP_MAX_ALARMS     8
#define HOOP_LOG_CAPACITY   32
#define HOOP_VOLUME_MAX     10
#define HOOP_TONE_COUNT     7
#define HOOP_SHOTS_MAX      9
#define HOOP_SETTINGS_VER   1

#define HOOP_USE_GLOBAL     0xFF   /* per-alarm tone/volume "use global setting" */
#define HOOP_TEST_ALARM_IDX 0xFE   /* log index for app-triggered test alarm */

/* One alarm slot - 8 bytes */
typedef struct __attribute__((packed)) {
    uint8_t enabled;          /* 0/1 */
    uint8_t hour;             /* 0..23 (local time) */
    uint8_t minute;           /* 0..59 */
    uint8_t days_mask;        /* bit0 = Sunday ... bit6 = Saturday, 0 = one-shot */
    uint8_t tone;             /* 0..HOOP_TONE_COUNT-1, 0xFF = global */
    uint8_t volume;           /* 1..10, 0xFF = global */
    uint8_t shots_required;   /* 1..9, 0 = global */
    uint8_t reserved;
} hoop_alarm_t;
_Static_assert(sizeof(hoop_alarm_t) == 8, "hoop_alarm_t size");

/* Global settings - 16 bytes */
typedef struct __attribute__((packed)) {
    uint8_t  version;           /* HOOP_SETTINGS_VER */
    uint8_t  volume;            /* 1..10 */
    uint8_t  tone;              /* 0..HOOP_TONE_COUNT-1 */
    uint8_t  shots_required;    /* baskets needed to silence the alarm, 1..9 */
    uint8_t  brightness;        /* display %, 5..100 */
    uint8_t  night_brightness;  /* display % during night window, 0..100 */
    uint8_t  night_start_hour;  /* 0..23; start == end disables night dimming */
    uint8_t  night_end_hour;    /* 0..23 */
    uint8_t  use_24h;           /* 0 = 12 h, 1 = 24 h */
    uint8_t  shot_window_s;     /* seconds after a ball drops before it counts as a miss */
    uint8_t  miss_delay_s;      /* delay after a miss before the next ball drops (5) */
    uint8_t  max_ring_min;      /* safety cut-off, 0 = ring until a basket */
    uint16_t ramp_after_s;      /* no basket for this long -> volume ramps up (90) */
    uint16_t reserved;
} hoop_settings_t;
_Static_assert(sizeof(hoop_settings_t) == 16, "hoop_settings_t size");

typedef enum {
    LOG_RESULT_MADE      = 0,   /* silenced by basket(s) */
    LOG_RESULT_TIMEOUT   = 1,   /* safety cut-off reached */
    LOG_RESULT_APP_STOP  = 2,   /* stopped from app (only if enabled) */
    LOG_RESULT_SKIPPED   = 3,   /* device was off / asleep past the grace window */
} hoop_log_result_t;

/* Alarm history entry - 12 bytes */
typedef struct __attribute__((packed)) {
    uint32_t start_epoch;         /* local time the alarm started */
    uint8_t  alarm_index;         /* slot, 0xFE = test */
    uint8_t  result;              /* hoop_log_result_t */
    uint8_t  shots_made;
    uint8_t  balls_dropped;
    uint16_t seconds_to_dismiss;
    uint8_t  misses;
    uint8_t  ramped;              /* 1 if the volume ramp kicked in */
} hoop_log_entry_t;
_Static_assert(sizeof(hoop_log_entry_t) == 12, "hoop_log_entry_t size");

typedef enum {
    HOOP_STATE_IDLE    = 0,
    HOOP_STATE_RINGING = 1,
    HOOP_STATE_OTA     = 2,
    HOOP_STATE_PREVIEW = 3,
} hoop_state_t;

/* status.flags */
#define ST_F_ON_BATTERY     (1u << 0)
#define ST_F_CHARGING       (1u << 1)
#define ST_F_BATT_LOW       (1u << 2)
#define ST_F_RTC_LOST_POWER (1u << 3)
#define ST_F_OUT_OF_BALLS   (1u << 4)
#define ST_F_HAS_SERVO      (1u << 5)
#define ST_F_HAS_DISPLAY    (1u << 6)
#define ST_F_TIME_VALID     (1u << 7)
/* status.flags2 */
#define ST_F2_ALARM_ARMED   (1u << 0)
#define ST_F2_RAMPING       (1u << 1)
#define ST_F2_RTC_OK        (1u << 2)
#define ST_F2_IR_BLOCKED    (1u << 3)

/* Live status - 24 bytes (BLE notify once per second) */
typedef struct __attribute__((packed)) {
    uint32_t now_epoch;
    uint32_t next_alarm_epoch;    /* 0 = none */
    uint8_t  state;               /* hoop_state_t */
    uint8_t  next_alarm_index;    /* 0xFF = none */
    uint8_t  shots_made;
    uint8_t  shots_required;
    uint8_t  balls_loaded;
    uint8_t  ring_volume;
    uint16_t batt_mv;             /* 0 on mains build */
    uint8_t  batt_pct;
    uint8_t  flags;
    int16_t  temp_c_x100;         /* DS3231 die temperature */
    uint8_t  fw[3];
    uint8_t  flags2;
} hoop_status_t;
_Static_assert(sizeof(hoop_status_t) == 24, "hoop_status_t size");
