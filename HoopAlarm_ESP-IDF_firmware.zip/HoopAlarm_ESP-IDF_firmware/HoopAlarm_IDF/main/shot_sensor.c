/*
 * shot_sensor.c - debounced IR shot detection
 */
#include "shot_sensor.h"
#include "app_config.h"
#include "driver/gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include "esp_timer.h"
#include "esp_check.h"
#include "esp_log.h"

static const char *TAG = "shot";

#define SHOT_MIN_US         ((int64_t)CONFIG_HOOP_SHOT_MIN_US)
#define SHOT_MAX_US         ((int64_t)CONFIG_HOOP_SHOT_MAX_MS * 1000)
#define SHOT_REFRACTORY_US  ((int64_t)CONFIG_HOOP_SHOT_REFRACTORY_MS * 1000)
#define EMITTER_SETTLE_MS   30

typedef struct {
    int64_t t_us;
    uint8_t level;
} edge_t;

static QueueHandle_t     s_q;
static shot_cb_t         s_cb;
static volatile bool     s_armed;
static volatile bool     s_blocked;
static volatile int64_t  s_blank_until_us;

static inline bool level_is_broken(int level)
{
    return HOOP_IR_ACTIVE_LOW ? (level == 0) : (level != 0);
}

static void ir_isr(void *arg)
{
    edge_t e = {
        .t_us = esp_timer_get_time(),
        .level = (uint8_t)gpio_get_level(PIN_IR_RX),
    };
    BaseType_t woken = pdFALSE;
    xQueueSendFromISR(s_q, &e, &woken);
    if (woken) {
        portYIELD_FROM_ISR();
    }
}

static void shot_task(void *arg)
{
    bool    broken = level_is_broken(gpio_get_level(PIN_IR_RX));
    int64_t t_break = esp_timer_get_time();
    int64_t last_shot = 0;

    for (;;) {
        edge_t e;
        if (xQueueReceive(s_q, &e, pdMS_TO_TICKS(50)) == pdTRUE) {
            bool now_broken = level_is_broken(e.level);

            if (now_broken && !broken) {
                broken = true;
                t_break = e.t_us;
            } else if (!now_broken && broken) {
                broken = false;
                s_blocked = false;
                int64_t dur = e.t_us - t_break;

                if (!s_armed) {
                    continue;
                }
                if (t_break < s_blank_until_us) {
                    ESP_LOGD(TAG, "ignored (blanking)");
                    continue;
                }
                if (dur < SHOT_MIN_US) {
                    ESP_LOGD(TAG, "glitch %lld us", dur);
                    continue;
                }
                if (dur > SHOT_MAX_US) {
                    ESP_LOGI(TAG, "blockage %lld ms ignored", dur / 1000);
                    continue;
                }
                if (last_shot && (t_break - last_shot) < SHOT_REFRACTORY_US) {
                    ESP_LOGD(TAG, "net bounce ignored");
                    continue;
                }
                last_shot = e.t_us;
                ESP_LOGI(TAG, "BASKET! beam broken %lld ms", dur / 1000);
                if (s_cb) {
                    s_cb((uint32_t)(dur / 1000));
                }
            }
        } else if (broken && !s_blocked && esp_timer_get_time() - t_break > SHOT_MAX_US) {
            s_blocked = true;
            ESP_LOGW(TAG, "beam blocked - check the hoop / sensor alignment");
        }
    }
}

esp_err_t shot_sensor_init(shot_cb_t cb)
{
    s_cb = cb;
    s_q = xQueueCreate(32, sizeof(edge_t));
    ESP_RETURN_ON_FALSE(s_q, ESP_ERR_NO_MEM, TAG, "queue");

    if (PIN_IR_EMITTER_EN >= 0) {
        gpio_config_t out = {
            .pin_bit_mask = 1ULL << PIN_IR_EMITTER_EN,
            .mode = GPIO_MODE_OUTPUT,
        };
        ESP_RETURN_ON_ERROR(gpio_config(&out), TAG, "emitter gpio");
        gpio_set_level(PIN_IR_EMITTER_EN, 0);
    }

    /* Break-beam receivers are open-collector: enable the pull-up
     * (GPIO34-39 have none - fit an external 10k there). */
    gpio_config_t in = {
        .pin_bit_mask = 1ULL << PIN_IR_RX,
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .intr_type = GPIO_INTR_ANYEDGE,
    };
    ESP_RETURN_ON_ERROR(gpio_config(&in), TAG, "rx gpio");
    ESP_RETURN_ON_ERROR(gpio_isr_handler_add(PIN_IR_RX, ir_isr, NULL), TAG, "isr");

    BaseType_t ok = xTaskCreatePinnedToCore(shot_task, "shot", 3072, NULL, PRIO_SHOT,
                                            NULL, CORE_REALTIME);
    ESP_RETURN_ON_FALSE(ok == pdPASS, ESP_ERR_NO_MEM, TAG, "task");
    ESP_LOGI(TAG, "IR sensor on GPIO%d (emitter EN GPIO%d)", PIN_IR_RX, PIN_IR_EMITTER_EN);
    return ESP_OK;
}

void shot_sensor_arm(bool armed)
{
    if (armed == s_armed) {
        return;
    }
    if (PIN_IR_EMITTER_EN >= 0) {
        gpio_set_level(PIN_IR_EMITTER_EN, armed ? 1 : 0);
    }
    if (armed) {
        shot_sensor_blank(EMITTER_SETTLE_MS + 20);
    }
    s_armed = armed;
}

void shot_sensor_blank(uint32_t ms)
{
    int64_t until = esp_timer_get_time() + (int64_t)ms * 1000;
    if (until > s_blank_until_us) {
        s_blank_until_us = until;
    }
}

bool shot_sensor_is_blocked(void)
{
    return s_blocked;
}
