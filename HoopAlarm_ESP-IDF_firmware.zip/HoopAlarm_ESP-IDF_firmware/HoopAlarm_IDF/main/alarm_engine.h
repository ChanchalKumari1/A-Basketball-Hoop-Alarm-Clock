/*
 * alarm_engine.h - the alarm state machine (task pinned to core 1).
 *
 * An alarm fires from any of three independent paths:
 *   1. the 1 Hz GPTimer tick ISR (phase-locked to the DS3231) -> EV_TICK
 *   2. the DS3231 Alarm-1 interrupt on the INT pin            -> EV_RTC_INT
 *   3. after a watchdog reset / deep-sleep wake, the boot check
 *      fires any alarm that is up to CONFIG_HOOP_ALARM_GRACE_S late.
 * Only a basket through the hoop (IR sensor) silences it.
 */
#pragma once

#include <stdint.h>
#include <stdbool.h>
#include "esp_sleep.h"
#include "hoop_types.h"

typedef enum {
    EV_TICK = 0,          /* u32 = epoch */
    EV_RTC_INT,
    EV_SHOT,              /* u32 = beam-break ms */
    EV_CONFIG_CHANGED,    /* alarms/settings rewritten by the app */
    EV_TIME_CHANGED,
    EV_CMD_TEST,          /* ring now (test from app) */
    EV_CMD_RELOAD,        /* a = balls now in the cradle */
    EV_CMD_APP_STOP,      /* only honoured if CONFIG_HOOP_ALLOW_APP_STOP */
    EV_CMD_DROP_BALL,     /* servo test */
    EV_CMD_PREVIEW,       /* a = tone, b = volume - 3 s preview */
    EV_CMD_PREVIEW_STOP,
} hoop_event_type_t;

typedef struct {
    uint8_t  type;
    uint8_t  a;
    uint8_t  b;
    uint32_t u32;
} hoop_event_t;

/* Creates the engine task on core 1 and blocks until core-1 peripherals are up. */
void     alarm_engine_start(esp_sleep_wakeup_cause_t wake);

bool     alarm_engine_post(uint8_t type, uint8_t a, uint8_t b, uint32_t u32);
void     alarm_engine_get_status(hoop_status_t *out);
bool     alarm_engine_is_busy(void);          /* ringing or previewing */
bool     alarm_engine_is_ringing(void);
uint32_t alarm_engine_seconds_to_next(void);  /* 0 = no alarm scheduled */
