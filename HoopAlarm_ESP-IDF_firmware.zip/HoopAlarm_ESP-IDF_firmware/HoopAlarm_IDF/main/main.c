/*
 * Basketball Hoop Alarm Clock - ESP32 firmware (ESP-IDF)
 *
 * An alarm you can't snooze: it only goes quiet when a ball goes through the hoop.
 *
 * Hardware
 *   ESP32-WROOM-32 .......... main MCU, BLE, dual core (BLE core 0 / alarm core 1)
 *   DS3231 + CR2032 ......... temperature-compensated RTC (I2C), INT -> wake/alarm
 *   IR break-beam (rim) ..... detects the ball passing through the hoop
 *   Piezo buzzer (NPN) ...... alarm tones, volume via PWM duty
 *   SG90 micro servo ........ releases one ball at a time from a 6-ball cradle
 *   4 x 2-digit 7-segment ... large display on a shift-register chain (mains build)
 *   LiPo 2000 mAh + TP4056 .. battery build with deep sleep (optional)
 *
 * Boot order matters: storage -> RTC -> outputs -> alarm engine (core 1) -> BLE (core 0).
 */
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "esp_ota_ops.h"
#include "esp_sleep.h"

#include "app_config.h"
#include "hoop_types.h"
#include "settings_store.h"
#include "event_log.h"
#include "ds3231.h"
#include "display.h"
#include "ui.h"
#include "buzzer.h"
#include "servo.h"
#include "alarm_engine.h"
#include "power.h"
#include "ble_service.h"

static const char *TAG = "main";

static const char *wake_name(esp_sleep_wakeup_cause_t w)
{
    switch (w) {
    case ESP_SLEEP_WAKEUP_EXT0:  return "DS3231 alarm";
    case ESP_SLEEP_WAKEUP_EXT1:  return "button";
    case ESP_SLEEP_WAKEUP_TIMER: return "backup timer";
    default:                     return "power-on/reset";
    }
}

void app_main(void)
{
    power_early_init();
    esp_sleep_wakeup_cause_t wake = esp_sleep_get_wakeup_cause();

    ESP_LOGI(TAG, "Hoop Alarm v%d.%d.%d | %s build | servo:%s display:%s | wake: %s",
             HOOP_FW_MAJOR, HOOP_FW_MINOR, HOOP_FW_PATCH,
             HOOP_ON_BATTERY ? "battery" : "mains",
             HOOP_HAS_SERVO ? "yes" : "no", HOOP_HAS_DISPLAY ? "yes" : "no",
             wake_name(wake));

    /* 1. persistent storage (alarms, settings, history) */
    ESP_ERROR_CHECK(store_init());
    ESP_ERROR_CHECK(event_log_init());

    /* 2. real-time clock - the alarm still works on the tick timer if it's missing,
     *    but time is lost at power-off, so make the fault visible */
    esp_err_t rtc_err = ds3231_init(PIN_I2C_SDA, PIN_I2C_SCL);

    /* 3. outputs */
    ESP_ERROR_CHECK(display_init());
    ESP_ERROR_CHECK(buzzer_init());
    ESP_ERROR_CHECK(servo_init());
    ui_start();
    if (rtc_err != ESP_OK) {
        ui_show_message("Err rtc", 4000);
        buzzer_jingle(JINGLE_ERROR);
    } else if (wake == ESP_SLEEP_WAKEUP_UNDEFINED) {
        buzzer_jingle(JINGLE_BOOT);
    }

    /* 4. power + button */
    ESP_ERROR_CHECK(power_init(wake));

    /* 5. alarm engine on core 1 (also brings up tick timer, RTC INT and IR sensor ISRs
     *    on core 1). Fires immediately if this boot was the DS3231 alarm wake-up. */
    alarm_engine_start(wake);

    /* 6. BLE on core 0 */
    esp_err_t ble_err = ble_service_init();
    if (ble_err != ESP_OK) {
        ESP_LOGE(TAG, "BLE failed to start - alarm keeps working, setup unavailable");
    }

    /* 7. advertising policy, sleep management */
    power_start();

    /* New OTA image booted and the critical paths came up: cancel rollback. */
    if (ble_err == ESP_OK) {
        esp_ota_mark_app_valid_cancel_rollback();
    }

    ESP_LOGI(TAG, "running");
}
