/*
 * display.h - large 7-segment display: four two-digit modules (up to 8 digits),
 * each digit statically driven by one shift register in a daisy chain
 * (TPIC6B595 recommended for large LED segments, 74HC595 + drivers also OK).
 * SPI clocks the chain; the SPI CS line is the RCK latch; /OE is PWM-dimmed.
 */
#pragma once

#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"

esp_err_t display_init(void);

/* chars: HOOP_DISPLAY_DIGITS characters (no NUL needed), dp_mask bit i = DP of digit i */
void      display_render(const char *chars, uint8_t dp_mask);

/* text with '.' attached to the previous character, left aligned, padded with blanks */
void      display_print(const char *text);

void      display_set_brightness(uint8_t percent);
void      display_off(void);
