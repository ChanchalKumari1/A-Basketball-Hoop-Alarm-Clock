/*
 * ui.h - what the 7-segment display shows (task on core 1, 10 Hz).
 *
 * 8-digit layout:  [H H][M M][S S][I I]   colon = DP of digit CONFIG_HOOP_DISPLAY_COLON_DIGIT
 *   I I = "AL" alarm armed, "Lo" battery low, during an alarm: baskets still needed / "--" empty
 * 6-digit: HH MM SS     4-digit: HH MM
 * Ringing: time flashes at 2 Hz.  Pairing: passkey.  OTA: "OtA" + percent.
 */
#pragma once

#include <stdint.h>

void ui_start(void);
void ui_show_passkey(uint32_t passkey);
void ui_clear_passkey(void);
void ui_show_message(const char *text, uint32_t ms);
