/*
 * buzzer.c - alarm tones for a piezo buzzer (LEDC PWM, own task on core 1)
 */
#include "buzzer.h"
#include "hoop_types.h"
#include "app_config.h"
#include "driver/ledc.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_check.h"
#include "esp_log.h"

static const char *TAG = "buzzer";

#define DUTY_BITS   LEDC_TIMER_10_BIT
#define DUTY_HALF   512                 /* 50 % = loudest square wave */

typedef struct { uint16_t freq; uint16_t ms; } note_t;
typedef struct { const char *name; const note_t *notes; uint8_t n; } pattern_t;

#define N(x) (sizeof(x) / sizeof((x)[0]))

/* ---------- alarm tones (selectable from the app) ---------- */
static const note_t T_CLASSIC[] = {
    {2700, 100}, {0, 80}, {2700, 100}, {0, 80}, {2700, 100}, {0, 80}, {2700, 100}, {0, 600},
};
static const note_t T_SIREN[] = {
    {1400, 40}, {1700, 40}, {2000, 40}, {2300, 40}, {2600, 40}, {2900, 40}, {3200, 40}, {3500, 40},
    {3200, 40}, {2900, 40}, {2600, 40}, {2300, 40}, {2000, 40}, {1700, 40},
};
static const note_t T_CHIRP[] = {
    {3800, 40}, {0, 40}, {3800, 40}, {0, 40}, {3000, 120}, {0, 400},
};
static const note_t T_RISING[] = {
    {1500, 120}, {2000, 120}, {2500, 120}, {3000, 120}, {3500, 120}, {0, 300},
};
static const note_t T_PULSE[] = {
    {2400, 400}, {0, 300},
};
static const note_t T_ARCADE[] = {
    {1568, 90}, {0, 20}, {2093, 90}, {0, 20}, {2637, 90}, {0, 20}, {3136, 180}, {0, 350},
};
static const note_t T_BUZZER_HORN[] = {
    {1800, 700}, {0, 250},
};

static const pattern_t TONES[HOOP_TONE_COUNT] = {
    {"Classic", T_CLASSIC,     N(T_CLASSIC)},
    {"Siren",   T_SIREN,       N(T_SIREN)},
    {"Chirp",   T_CHIRP,       N(T_CHIRP)},
    {"Rising",  T_RISING,      N(T_RISING)},
    {"Pulse",   T_PULSE,       N(T_PULSE)},
    {"Arcade",  T_ARCADE,      N(T_ARCADE)},
    {"Horn",    T_BUZZER_HORN, N(T_BUZZER_HORN)},
};

/* ---------- one-shot jingles ---------- */
static const note_t J_BOOT[]    = { {2093, 60}, {2637, 60}, {3136, 90} };
static const note_t J_ACK[]     = { {3136, 60}, {0, 30}, {4186, 90}, {0, 250} };
static const note_t J_SUCCESS[] = { {2093, 80}, {2637, 80}, {3136, 80}, {4186, 250} };
static const note_t J_ERROR[]   = { {800, 300}, {0, 100}, {800, 300} };
static const note_t J_BLE[]     = { {3500, 40} };

static const pattern_t JINGLES[] = {
    [JINGLE_BOOT]    = {"boot",    J_BOOT,    N(J_BOOT)},
    [JINGLE_ACK]     = {"ack",     J_ACK,     N(J_ACK)},
    [JINGLE_SUCCESS] = {"success", J_SUCCESS, N(J_SUCCESS)},
    [JINGLE_ERROR]   = {"error",   J_ERROR,   N(J_ERROR)},
    [JINGLE_BLE]     = {"ble",     J_BLE,     N(J_BLE)},
};

/* volume 0..10 -> duty (perceived loudness of a piezo is very non-linear) */
static const uint16_t VOL_DUTY[HOOP_VOLUME_MAX + 1] = {
    0, 6, 12, 22, 38, 60, 95, 150, 230, 360, DUTY_HALF,
};

static portMUX_TYPE        s_mux = portMUX_INITIALIZER_UNLOCKED;
static TaskHandle_t        s_task;
static int                 s_main = -1;          /* tone index or -1 */
static bool                s_main_loop;
static const pattern_t    *s_overlay;
static volatile uint8_t    s_volume = 7;
static volatile uint8_t    s_tempo = 100;
static volatile uint32_t   s_gen;                /* bumped on every pattern change */

static void out_note(uint16_t freq, uint8_t vol)
{
    if (freq == 0 || vol == 0) {
        ledc_set_duty(HOOP_LEDC_MODE, BUZZER_LEDC_CHANNEL, 0);
    } else {
        ledc_set_freq(HOOP_LEDC_MODE, BUZZER_LEDC_TIMER, freq);
        ledc_set_duty(HOOP_LEDC_MODE, BUZZER_LEDC_CHANNEL, VOL_DUTY[vol > HOOP_VOLUME_MAX ? HOOP_VOLUME_MAX : vol]);
    }
    ledc_update_duty(HOOP_LEDC_MODE, BUZZER_LEDC_CHANNEL);
}

static void buzzer_task(void *arg)
{
    for (;;) {
        const pattern_t *pat = NULL;
        bool loop = false, is_overlay = false;
        uint32_t gen;

        taskENTER_CRITICAL(&s_mux);
        gen = s_gen;
        if (s_overlay) {
            pat = s_overlay;
            is_overlay = true;
        } else if (s_main >= 0) {
            pat = &TONES[s_main];
            loop = s_main_loop;
        }
        taskEXIT_CRITICAL(&s_mux);

        if (!pat) {
            out_note(0, 0);
            ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
            continue;
        }

        bool interrupted = false;
        do {
            for (uint8_t i = 0; i < pat->n && !interrupted; i++) {
                /* jingles always play at a fixed, clearly audible level */
                out_note(pat->notes[i].freq, is_overlay ? 8 : s_volume);
                uint32_t ms = (uint32_t)pat->notes[i].ms * (is_overlay ? 100 : s_tempo) / 100;
                ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(ms ? ms : 1));
                interrupted = (s_gen != gen);
            }
        } while (!interrupted && loop);

        if (!interrupted) {
            taskENTER_CRITICAL(&s_mux);
            if (s_gen == gen) {
                if (is_overlay) {
                    s_overlay = NULL;      /* fall back to the looping alarm tone, if any */
                } else if (!loop) {
                    s_main = -1;
                }
            }
            taskEXIT_CRITICAL(&s_mux);
        }
    }
}

static void kick(void)
{
    if (s_task) {
        xTaskNotifyGive(s_task);
    }
}

esp_err_t buzzer_init(void)
{
    ledc_timer_config_t t = {
        .speed_mode = HOOP_LEDC_MODE,
        .duty_resolution = DUTY_BITS,
        .timer_num = BUZZER_LEDC_TIMER,
        .freq_hz = 2700,
        .clk_cfg = LEDC_AUTO_CLK,
    };
    ESP_RETURN_ON_ERROR(ledc_timer_config(&t), TAG, "timer");

    ledc_channel_config_t c = {
        .gpio_num = PIN_BUZZER,
        .speed_mode = HOOP_LEDC_MODE,
        .channel = BUZZER_LEDC_CHANNEL,
        .timer_sel = BUZZER_LEDC_TIMER,
        .duty = 0,
        .hpoint = 0,
        .intr_type = LEDC_INTR_DISABLE,
    };
    ESP_RETURN_ON_ERROR(ledc_channel_config(&c), TAG, "channel");

    BaseType_t ok = xTaskCreatePinnedToCore(buzzer_task, "buzzer", 2560, NULL, PRIO_BUZZER,
                                            &s_task, CORE_REALTIME);
    ESP_RETURN_ON_FALSE(ok == pdPASS, ESP_ERR_NO_MEM, TAG, "task");
    return ESP_OK;
}

void buzzer_play(uint8_t tone, uint8_t volume, bool loop)
{
    if (tone >= HOOP_TONE_COUNT) {
        tone = 0;
    }
    taskENTER_CRITICAL(&s_mux);
    s_main = tone;
    s_main_loop = loop;
    s_overlay = NULL;
    s_volume = volume > HOOP_VOLUME_MAX ? HOOP_VOLUME_MAX : volume;
    s_tempo = 100;
    s_gen++;
    taskEXIT_CRITICAL(&s_mux);
    kick();
    ESP_LOGI(TAG, "play '%s' vol %u%s", TONES[tone].name, volume, loop ? " (loop)" : "");
}

void buzzer_stop(void)
{
    taskENTER_CRITICAL(&s_mux);
    s_main = -1;
    s_overlay = NULL;
    s_gen++;
    taskEXIT_CRITICAL(&s_mux);
    kick();
}

void buzzer_set_volume(uint8_t volume)
{
    s_volume = volume > HOOP_VOLUME_MAX ? HOOP_VOLUME_MAX : volume;
}

void buzzer_set_tempo(uint8_t percent)
{
    s_tempo = percent < 20 ? 20 : percent;
}

void buzzer_jingle(buzzer_jingle_t j)
{
    if ((unsigned)j >= N(JINGLES)) {
        return;
    }
    taskENTER_CRITICAL(&s_mux);
    s_overlay = &JINGLES[j];
    s_gen++;
    taskEXIT_CRITICAL(&s_mux);
    kick();
}

bool buzzer_is_active(void)
{
    return s_main >= 0 || s_overlay != NULL;
}

const char *buzzer_tone_name(uint8_t tone)
{
    return tone < HOOP_TONE_COUNT ? TONES[tone].name : "?";
}
