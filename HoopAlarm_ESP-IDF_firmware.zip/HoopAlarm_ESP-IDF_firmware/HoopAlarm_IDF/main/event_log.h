/*
 * event_log.h - ring buffer of recent alarms and whether the shot was made
 * (shown in the app's history screen). Persisted in NVS.
 */
#pragma once

#include <stdint.h>
#include "esp_err.h"
#include "hoop_types.h"

esp_err_t event_log_init(void);
esp_err_t event_log_add(const hoop_log_entry_t *e);
uint8_t   event_log_read(hoop_log_entry_t *out, uint8_t max);   /* newest first */
esp_err_t event_log_clear(void);
