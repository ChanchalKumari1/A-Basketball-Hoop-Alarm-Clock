/*
 * ble_service.c - custom GATT service for the React Native companion app
 *
 * Service 484f4f50-0001-4c41-524d-2d4553503332  ("HOOP" ... "LARM-ESP32")
 *   0002 Time        R/W   current local time
 *   0003 Alarms      R/W   alarm table
 *   0004 Settings    R/W   volume, tone, baskets-to-dismiss, display, timings
 *   0005 Status      R/N   live status, notified every second
 *   0006 Log         R     recent alarms and whether the shot was made
 *   0007 Command     W     test alarm, reload balls, tone preview, ...
 *   0008 OTA control R/W   begin / finish / abort firmware update
 *   0009 OTA data    W     firmware image chunks
 *   000A Device info R     firmware version + hardware capabilities (no pairing needed)
 *
 * Security: LE Secure Connections, MITM, bonding. The device displays a passkey
 * (on the 7-segment display, or a fixed code when no display is fitted).
 */
#include <string.h>
#include "ble_service.h"
#include "app_config.h"
#include "hoop_types.h"
#include "time_util.h"
#include "timekeeper.h"
#include "ds3231.h"
#include "alarm_engine.h"
#include "settings_store.h"
#include "event_log.h"
#include "ota_update.h"
#include "power.h"
#include "ui.h"
#include "buzzer.h"

#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "host/ble_hs.h"
#include "host/ble_store.h"
#include "host/util/util.h"
#include "services/gap/ble_svc_gap.h"
#include "services/gatt/ble_svc_gatt.h"

#include "freertos/FreeRTOS.h"
#include "freertos/timers.h"
#include "esp_random.h"
#include "esp_timer.h"
#include "esp_system.h"
#include "esp_log.h"

static const char *TAG = "ble";

void ble_store_config_init(void);   /* provided by NimBLE, no public header */

/* ---------- application ATT error codes (0x80..0x9F) ---------- */
#define HOOP_ATT_ERR_INVALID    0x80   /* value out of range */
#define HOOP_ATT_ERR_BUSY       0x81   /* alarm ringing / OTA running */
#define HOOP_ATT_ERR_OTA        0x82   /* flash / image error */
#define HOOP_ATT_ERR_CRC        0x83   /* OTA CRC mismatch */
#define HOOP_ATT_ERR_REFUSED    0x84   /* operation not allowed in this build */

/* ---------- UUIDs: 484f4f50-XXXX-4c41-524d-2d4553503332 (little-endian bytes) ---------- */
#define HOOP_UUID(id) BLE_UUID128_INIT(0x32, 0x33, 0x50, 0x53, 0x45, 0x2d, 0x4d, 0x52, \
                                       0x41, 0x4c, ((id) & 0xff), (((id) >> 8) & 0xff), \
                                       0x50, 0x4f, 0x4f, 0x48)

static const ble_uuid128_t UUID_SVC      = HOOP_UUID(0x0001);
static const ble_uuid128_t UUID_TIME     = HOOP_UUID(0x0002);
static const ble_uuid128_t UUID_ALARMS   = HOOP_UUID(0x0003);
static const ble_uuid128_t UUID_SETTINGS = HOOP_UUID(0x0004);
static const ble_uuid128_t UUID_STATUS   = HOOP_UUID(0x0005);
static const ble_uuid128_t UUID_LOG      = HOOP_UUID(0x0006);
static const ble_uuid128_t UUID_CMD      = HOOP_UUID(0x0007);
static const ble_uuid128_t UUID_OTA_CTRL = HOOP_UUID(0x0008);
static const ble_uuid128_t UUID_OTA_DATA = HOOP_UUID(0x0009);
static const ble_uuid128_t UUID_INFO     = HOOP_UUID(0x000A);

enum {
    CHR_TIME, CHR_ALARMS, CHR_SETTINGS, CHR_STATUS, CHR_LOG,
    CHR_CMD, CHR_OTA_CTRL, CHR_OTA_DATA, CHR_INFO,
};

enum {
    CMD_TEST_ALARM   = 0x01,
    CMD_RELOAD_BALLS = 0x02,   /* [n] (0 = full) */
    CMD_PREVIEW_TONE = 0x03,   /* [tone][volume] */
    CMD_STOP_PREVIEW = 0x04,
    CMD_DROP_BALL    = 0x05,
    CMD_CLEAR_LOG    = 0x06,
    CMD_END_SESSION  = 0x07,   /* disconnect + radio off (setup done) */
    CMD_REBOOT       = 0x08,
    CMD_FACTORY_RST  = 0x09,
    CMD_STOP_ALARM   = 0x0A,   /* refused unless CONFIG_HOOP_ALLOW_APP_STOP */
};

enum { OTA_OP_BEGIN = 0x01, OTA_OP_FINISH = 0x02, OTA_OP_ABORT = 0x03 };

#define F_READ   (BLE_GATT_CHR_F_READ | BLE_GATT_CHR_F_READ_ENC | BLE_GATT_CHR_F_READ_AUTHEN)
#define F_WRITE  (BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_ENC | BLE_GATT_CHR_F_WRITE_AUTHEN)

/* ---------- state ---------- */
static uint8_t           s_own_addr_type;
static volatile bool     s_synced;
static volatile uint16_t s_conn = BLE_HS_CONN_HANDLE_NONE;
static volatile bool     s_adv_wanted;
static volatile int64_t  s_adv_deadline_us;      /* 0 = no deadline */
static volatile int64_t  s_pairing_open_until_us;
static uint16_t          s_status_handle;
static volatile bool     s_status_subscribed;
static TimerHandle_t     s_notify_timer;
static esp_timer_handle_t s_restart_timer;
static uint8_t           s_buf[520];             /* host task is single-threaded */

static int  gap_event(struct ble_gap_event *event, void *arg);
static void adv_start(void);

/* ---------- helpers ---------- */

static inline uint32_t rd_u32(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static void restart_cb(void *arg)
{
    esp_restart();
}

static void schedule_restart(uint32_t ms)
{
    if (!s_restart_timer) {
        const esp_timer_create_args_t a = { .callback = restart_cb, .name = "ble_rst" };
        esp_timer_create(&a, &s_restart_timer);
    }
    esp_timer_start_once(s_restart_timer, (uint64_t)ms * 1000);
}

static int bonded_count(void)
{
    ble_addr_t peers[4];
    int n = 0;
    if (ble_store_util_bonded_peers(peers, &n, 4) != 0) {
        return 0;
    }
    return n;
}

static bool pairing_allowed(void)
{
    if (!HOOP_PAIRING_NEEDS_BUTTON) {
        return true;
    }
    return bonded_count() == 0 || esp_timer_get_time() < s_pairing_open_until_us;
}

static int append(struct os_mbuf *om, const void *data, uint16_t len)
{
    return os_mbuf_append(om, data, len) == 0 ? 0 : BLE_ATT_ERR_INSUFFICIENT_RES;
}

/* ---------- reads ---------- */

static int on_read(int id, struct os_mbuf *om)
{
    switch (id) {
    case CHR_TIME: {
        struct __attribute__((packed)) {
            uint32_t now;
            uint8_t  valid;
            uint8_t  rtc_present;
            int16_t  temp_c_x100;
        } t = {
            .now = timekeeper_now(),
            .valid = timekeeper_valid(),
            .rtc_present = ds3231_present(),
            .temp_c_x100 = timekeeper_temperature(),
        };
        return append(om, &t, sizeof(t));
    }
    case CHR_ALARMS: {
        hoop_alarm_t a[HOOP_MAX_ALARMS];
        uint8_t n = store_get_alarms(a);
        s_buf[0] = n;
        memcpy(&s_buf[1], a, n * sizeof(hoop_alarm_t));
        return append(om, s_buf, (uint16_t)(1 + n * sizeof(hoop_alarm_t)));
    }
    case CHR_SETTINGS: {
        hoop_settings_t s;
        store_get_settings(&s);
        return append(om, &s, sizeof(s));
    }
    case CHR_STATUS: {
        hoop_status_t st;
        alarm_engine_get_status(&st);
        return append(om, &st, sizeof(st));
    }
    case CHR_LOG: {
        hoop_log_entry_t e[HOOP_LOG_CAPACITY];
        uint8_t n = event_log_read(e, HOOP_LOG_CAPACITY);
        s_buf[0] = n;
        memcpy(&s_buf[1], e, n * sizeof(hoop_log_entry_t));
        return append(om, s_buf, (uint16_t)(1 + n * sizeof(hoop_log_entry_t)));
    }
    case CHR_OTA_CTRL: {
        struct __attribute__((packed)) {
            uint8_t  active;
            uint8_t  pct;
            uint32_t received;
            uint32_t size;
        } o = {
            .active = ota_update_in_progress(),
            .pct = ota_update_progress_pct(),
            .received = ota_update_received(),
            .size = ota_update_size(),
        };
        return append(om, &o, sizeof(o));
    }
    case CHR_INFO: {
        struct __attribute__((packed)) {
            uint8_t fw[3];
            uint8_t hw_flags;        /* bit0 servo, bit1 display, bit2 battery */
            uint8_t tone_count;
            uint8_t max_alarms;
            uint8_t ball_capacity;
            uint8_t display_digits;
            uint8_t log_capacity;
            uint8_t protocol;
        } i = {
            .fw = { HOOP_FW_MAJOR, HOOP_FW_MINOR, HOOP_FW_PATCH },
            .hw_flags = (uint8_t)((HOOP_HAS_SERVO ? 1 : 0) | (HOOP_HAS_DISPLAY ? 2 : 0) |
                                  (HOOP_ON_BATTERY ? 4 : 0)),
            .tone_count = HOOP_TONE_COUNT,
            .max_alarms = HOOP_MAX_ALARMS,
            .ball_capacity = HOOP_BALL_CAPACITY,
            .display_digits = HOOP_HAS_DISPLAY ? HOOP_DISPLAY_DIGITS : 0,
            .log_capacity = HOOP_LOG_CAPACITY,
            .protocol = 1,
        };
        return append(om, &i, sizeof(i));
    }
    default:
        return BLE_ATT_ERR_READ_NOT_PERMITTED;
    }
}

/* ---------- writes ---------- */

static int on_command(const uint8_t *d, uint16_t len)
{
    if (len < 1) {
        return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;
    }
    switch (d[0]) {
    case CMD_TEST_ALARM:
        if (alarm_engine_is_ringing()) {
            return HOOP_ATT_ERR_BUSY;
        }
        alarm_engine_post(EV_CMD_TEST, 0, 0, 0);
        return 0;
    case CMD_RELOAD_BALLS:
        alarm_engine_post(EV_CMD_RELOAD, len >= 2 ? d[1] : 0, 0, 0);
        return 0;
    case CMD_PREVIEW_TONE:
        if (len < 3 || d[1] >= HOOP_TONE_COUNT || d[2] > HOOP_VOLUME_MAX) {
            return HOOP_ATT_ERR_INVALID;
        }
        alarm_engine_post(EV_CMD_PREVIEW, d[1], d[2], 0);
        return 0;
    case CMD_STOP_PREVIEW:
        alarm_engine_post(EV_CMD_PREVIEW_STOP, 0, 0, 0);
        return 0;
    case CMD_DROP_BALL:
        if (!HOOP_HAS_SERVO) {
            return HOOP_ATT_ERR_REFUSED;
        }
        alarm_engine_post(EV_CMD_DROP_BALL, 0, 0, 0);
        return 0;
    case CMD_CLEAR_LOG:
        event_log_clear();
        return 0;
    case CMD_END_SESSION:
        /* app pushed its settings and is done: drop the link, radio goes quiet */
        s_adv_wanted = false;
        if (s_conn != BLE_HS_CONN_HANDLE_NONE) {
            ble_gap_terminate(s_conn, BLE_ERR_REM_USER_CONN_TERM);
        }
        return 0;
    case CMD_REBOOT:
        if (alarm_engine_is_ringing()) {
            return HOOP_ATT_ERR_BUSY;
        }
        schedule_restart(500);
        return 0;
    case CMD_FACTORY_RST:
        if (alarm_engine_is_ringing()) {
            return HOOP_ATT_ERR_BUSY;
        }
        store_factory_reset();
        event_log_clear();
        ble_store_clear();
        schedule_restart(500);
        return 0;
    case CMD_STOP_ALARM:
        if (!HOOP_ALLOW_APP_STOP) {
            return HOOP_ATT_ERR_REFUSED;
        }
        alarm_engine_post(EV_CMD_APP_STOP, 0, 0, 0);
        return 0;
    default:
        return BLE_ATT_ERR_REQ_NOT_SUPPORTED;
    }
}

static int on_ota_ctrl(const uint8_t *d, uint16_t len)
{
    if (len < 1) {
        return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;
    }
    esp_err_t err;
    switch (d[0]) {
    case OTA_OP_BEGIN:
        if (len < 5) {
            return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;
        }
        if (alarm_engine_is_ringing()) {
            return HOOP_ATT_ERR_BUSY;     /* never update while the alarm is going off */
        }
        err = ota_update_begin(rd_u32(&d[1]));
        if (err == ESP_OK) {
            /* fast connection interval for throughput */
            struct ble_gap_upd_params p = {
                .itvl_min = 6, .itvl_max = 12, .latency = 0,
                .supervision_timeout = 400, .min_ce_len = 0, .max_ce_len = 0,
            };
            ble_gap_update_params(s_conn, &p);
        }
        return err == ESP_OK ? 0 : (err == ESP_ERR_INVALID_SIZE ? HOOP_ATT_ERR_INVALID : HOOP_ATT_ERR_OTA);
    case OTA_OP_FINISH:
        if (len < 5) {
            return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;
        }
        err = ota_update_finish(rd_u32(&d[1]));
        return err == ESP_OK ? 0 : (err == ESP_ERR_INVALID_CRC ? HOOP_ATT_ERR_CRC : HOOP_ATT_ERR_OTA);
    case OTA_OP_ABORT:
        ota_update_abort();
        return 0;
    default:
        return BLE_ATT_ERR_REQ_NOT_SUPPORTED;
    }
}

static int on_write(int id, const uint8_t *d, uint16_t len)
{
    switch (id) {
    case CHR_TIME: {
        if (len < 4) {
            return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;
        }
        uint32_t epoch = rd_u32(d);
        if (epoch < TU_EPOCH_2024) {
            return HOOP_ATT_ERR_INVALID;
        }
        if (timekeeper_set_time(epoch) != ESP_OK) {
            ESP_LOGW(TAG, "DS3231 write failed - running on tick only");
        }
        alarm_engine_post(EV_TIME_CHANGED, 0, 0, 0);
        timekeeper_request_resync();
        return 0;
    }
    case CHR_ALARMS: {
        if (len < 1) {
            return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;
        }
        uint8_t n = d[0];
        if (n > HOOP_MAX_ALARMS || len != 1 + n * sizeof(hoop_alarm_t)) {
            return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;
        }
        hoop_alarm_t a[HOOP_MAX_ALARMS];
        memcpy(a, &d[1], n * sizeof(hoop_alarm_t));
        esp_err_t err = store_set_alarms(a, n);
        if (err == ESP_ERR_INVALID_ARG) {
            return HOOP_ATT_ERR_INVALID;
        }
        if (err != ESP_OK) {
            return BLE_ATT_ERR_UNLIKELY;
        }
        alarm_engine_post(EV_CONFIG_CHANGED, 0, 0, 0);
        return 0;
    }
    case CHR_SETTINGS: {
        if (len != sizeof(hoop_settings_t)) {
            return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;
        }
        hoop_settings_t s;
        memcpy(&s, d, sizeof(s));
        if (!store_validate_settings(&s)) {
            return HOOP_ATT_ERR_INVALID;
        }
        if (store_set_settings(&s) != ESP_OK) {
            return BLE_ATT_ERR_UNLIKELY;
        }
        alarm_engine_post(EV_CONFIG_CHANGED, 0, 0, 0);
        return 0;
    }
    case CHR_CMD:
        return on_command(d, len);
    case CHR_OTA_CTRL:
        return on_ota_ctrl(d, len);
    case CHR_OTA_DATA: {
        esp_err_t err = ota_update_write(d, len);
        if (err == ESP_ERR_INVALID_STATE) {
            return HOOP_ATT_ERR_BUSY;
        }
        return err == ESP_OK ? 0 : HOOP_ATT_ERR_OTA;
    }
    default:
        return BLE_ATT_ERR_WRITE_NOT_PERMITTED;
    }
}

static int chr_access(uint16_t conn_handle, uint16_t attr_handle,
                      struct ble_gatt_access_ctxt *ctxt, void *arg)
{
    int id = (int)(intptr_t)arg;
    power_note_activity();

    if (ctxt->op == BLE_GATT_ACCESS_OP_READ_CHR) {
        return on_read(id, ctxt->om);
    }
    if (ctxt->op == BLE_GATT_ACCESS_OP_WRITE_CHR) {
        uint16_t len = OS_MBUF_PKTLEN(ctxt->om);
        if (len > sizeof(s_buf)) {
            return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;
        }
        uint16_t out_len = 0;
        if (ble_hs_mbuf_to_flat(ctxt->om, s_buf, sizeof(s_buf), &out_len) != 0) {
            return BLE_ATT_ERR_UNLIKELY;
        }
        return on_write(id, s_buf, out_len);
    }
    return BLE_ATT_ERR_UNLIKELY;
}

/* ---------- GATT table ---------- */

static const struct ble_gatt_svc_def s_svcs[] = {
    {
        .type = BLE_GATT_SVC_TYPE_PRIMARY,
        .uuid = &UUID_SVC.u,
        .characteristics = (struct ble_gatt_chr_def[]) {
            { .uuid = &UUID_TIME.u,     .access_cb = chr_access, .arg = (void *)CHR_TIME,
              .flags = F_READ | F_WRITE },
            { .uuid = &UUID_ALARMS.u,   .access_cb = chr_access, .arg = (void *)CHR_ALARMS,
              .flags = F_READ | F_WRITE },
            { .uuid = &UUID_SETTINGS.u, .access_cb = chr_access, .arg = (void *)CHR_SETTINGS,
              .flags = F_READ | F_WRITE },
            { .uuid = &UUID_STATUS.u,   .access_cb = chr_access, .arg = (void *)CHR_STATUS,
              .flags = F_READ | BLE_GATT_CHR_F_NOTIFY, .val_handle = &s_status_handle },
            { .uuid = &UUID_LOG.u,      .access_cb = chr_access, .arg = (void *)CHR_LOG,
              .flags = F_READ },
            { .uuid = &UUID_CMD.u,      .access_cb = chr_access, .arg = (void *)CHR_CMD,
              .flags = F_WRITE },
            { .uuid = &UUID_OTA_CTRL.u, .access_cb = chr_access, .arg = (void *)CHR_OTA_CTRL,
              .flags = F_READ | F_WRITE },
            { .uuid = &UUID_OTA_DATA.u, .access_cb = chr_access, .arg = (void *)CHR_OTA_DATA,
              .flags = F_WRITE },
            { .uuid = &UUID_INFO.u,     .access_cb = chr_access, .arg = (void *)CHR_INFO,
              .flags = BLE_GATT_CHR_F_READ },
            { 0 },
        },
    },
    { 0 },
};

/* ---------- status notifications ---------- */

static void notify_timer_cb(TimerHandle_t t)
{
    uint16_t conn = s_conn;
    if (conn == BLE_HS_CONN_HANDLE_NONE || !s_status_subscribed) {
        return;
    }
    struct ble_gap_conn_desc desc;
    if (ble_gap_conn_find(conn, &desc) != 0 || !desc.sec_state.authenticated) {
        return;
    }
    hoop_status_t st;
    alarm_engine_get_status(&st);
    struct os_mbuf *om = ble_hs_mbuf_from_flat(&st, sizeof(st));
    if (om) {
        ble_gatts_notify_custom(conn, s_status_handle, om);
    }
}

/* ---------- advertising ---------- */

static bool adv_window_open(void)
{
    if (!s_adv_wanted) {
        return false;
    }
    return s_adv_deadline_us == 0 || esp_timer_get_time() < s_adv_deadline_us;
}

static void adv_start(void)
{
    if (!s_synced || s_conn != BLE_HS_CONN_HANDLE_NONE || !adv_window_open()) {
        return;
    }
    if (ble_gap_adv_active()) {
        ble_gap_adv_stop();
    }

    struct ble_hs_adv_fields fields = {0};
    const char *name = ble_svc_gap_device_name();
    fields.flags = BLE_HS_ADV_F_DISC_GEN | BLE_HS_ADV_F_BREDR_UNSUP;
    fields.name = (uint8_t *)name;
    fields.name_len = (uint8_t)strlen(name);
    fields.name_is_complete = 1;
    fields.tx_pwr_lvl_is_present = 1;
    fields.tx_pwr_lvl = BLE_HS_ADV_TX_PWR_LVL_AUTO;
    int rc = ble_gap_adv_set_fields(&fields);
    if (rc != 0) {
        ESP_LOGE(TAG, "adv fields rc=%d", rc);
        return;
    }

    struct ble_hs_adv_fields rsp = {0};
    rsp.uuids128 = &UUID_SVC;
    rsp.num_uuids128 = 1;
    rsp.uuids128_is_complete = 1;
    ble_gap_adv_rsp_set_fields(&rsp);

    int32_t duration_ms = BLE_HS_FOREVER;
    if (s_adv_deadline_us) {
        int64_t rem = (s_adv_deadline_us - esp_timer_get_time()) / 1000;
        if (rem <= 0) {
            return;
        }
        duration_ms = (int32_t)rem;
    }

    struct ble_gap_adv_params params = {0};
    params.conn_mode = BLE_GAP_CONN_MODE_UND;
    params.disc_mode = BLE_GAP_DISC_MODE_GEN;
    params.itvl_min = BLE_GAP_ADV_ITVL_MS(200);
    params.itvl_max = BLE_GAP_ADV_ITVL_MS(300);

    rc = ble_gap_adv_start(s_own_addr_type, NULL, duration_ms, &params, gap_event, NULL);
    if (rc == 0) {
        ESP_LOGI(TAG, "advertising as '%s'%s", name, s_adv_deadline_us ? "" : " (always on)");
    } else {
        ESP_LOGE(TAG, "adv start rc=%d", rc);
    }
}

/* ---------- GAP events ---------- */

static int gap_event(struct ble_gap_event *event, void *arg)
{
    struct ble_gap_conn_desc desc;

    switch (event->type) {
    case BLE_GAP_EVENT_CONNECT:
        if (event->connect.status == 0) {
            s_conn = event->connect.conn_handle;
            ESP_LOGI(TAG, "connected (handle %u)", s_conn);
            power_note_activity();
            ble_gap_security_initiate(s_conn);      /* prompt pairing / re-encrypt bond */
        } else {
            s_conn = BLE_HS_CONN_HANDLE_NONE;
            adv_start();
        }
        return 0;

    case BLE_GAP_EVENT_DISCONNECT:
        ESP_LOGI(TAG, "disconnected (reason 0x%02x)", event->disconnect.reason);
        s_conn = BLE_HS_CONN_HANDLE_NONE;
        s_status_subscribed = false;
        ui_clear_passkey();
        if (ota_update_in_progress()) {
            ota_update_abort();
        }
        power_note_activity();
        adv_start();
        return 0;

    case BLE_GAP_EVENT_ADV_COMPLETE:
        ESP_LOGI(TAG, "advertising window closed - radio idle");
        return 0;

    case BLE_GAP_EVENT_PASSKEY_ACTION:
        if (!pairing_allowed()) {
            ESP_LOGW(TAG, "pairing refused: press the button on the hoop first");
            ble_gap_terminate(event->passkey.conn_handle, BLE_ERR_AUTH_FAIL);
            return 0;
        }
        if (event->passkey.params.action == BLE_SM_IOACT_DISP) {
            struct ble_sm_io pk = {0};
            pk.action = BLE_SM_IOACT_DISP;
            pk.passkey = HOOP_HAS_DISPLAY ? (esp_random() % 1000000u)
                                          : (uint32_t)CONFIG_HOOP_BLE_STATIC_PASSKEY;
            ui_show_passkey(pk.passkey);
            ESP_LOGI(TAG, "passkey %06lu", (unsigned long)pk.passkey);
            ble_sm_inject_io(event->passkey.conn_handle, &pk);
        } else {
            ESP_LOGW(TAG, "unsupported pairing action %d", event->passkey.params.action);
        }
        return 0;

    case BLE_GAP_EVENT_ENC_CHANGE:
        ui_clear_passkey();
        if (event->enc_change.status == 0) {
            ESP_LOGI(TAG, "link encrypted + authenticated");
            buzzer_jingle(JINGLE_BLE);
        } else {
            ESP_LOGW(TAG, "encryption failed (%d)", event->enc_change.status);
        }
        return 0;

    case BLE_GAP_EVENT_REPEAT_PAIRING:
        /* phone lost its bond: forget ours and let it pair again (subject to the gate) */
        if (ble_gap_conn_find(event->repeat_pairing.conn_handle, &desc) == 0) {
            ble_store_util_delete_peer(&desc.peer_id_addr);
        }
        return BLE_GAP_REPEAT_PAIRING_RETRY;

    case BLE_GAP_EVENT_SUBSCRIBE:
        if (event->subscribe.attr_handle == s_status_handle) {
            s_status_subscribed = event->subscribe.cur_notify;
        }
        return 0;

    case BLE_GAP_EVENT_MTU:
        ESP_LOGI(TAG, "MTU %u", event->mtu.value);
        return 0;

    default:
        return 0;
    }
}

/* ---------- host lifecycle ---------- */

static void on_sync(void)
{
    ble_hs_util_ensure_addr(0);
    ble_hs_id_infer_auto(0, &s_own_addr_type);
    s_synced = true;
    ESP_LOGI(TAG, "BLE host synced, %d bonded phone(s)", bonded_count());
    adv_start();
}

static void on_reset(int reason)
{
    s_synced = false;
    ESP_LOGW(TAG, "BLE host reset, reason %d", reason);
}

static void host_task(void *param)
{
    nimble_port_run();               /* returns only after nimble_port_stop() */
    nimble_port_freertos_deinit();
}

esp_err_t ble_service_init(void)
{
    esp_err_t err = nimble_port_init();
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "nimble init: %s", esp_err_to_name(err));
        return err;
    }

    ble_hs_cfg.reset_cb = on_reset;
    ble_hs_cfg.sync_cb = on_sync;
    ble_hs_cfg.store_status_cb = ble_store_util_status_rr;

    /* LE Secure Connections + MITM (passkey) + bonding */
    ble_hs_cfg.sm_io_cap = BLE_SM_IO_CAP_DISP_ONLY;
    ble_hs_cfg.sm_bonding = 1;
    ble_hs_cfg.sm_mitm = 1;
    ble_hs_cfg.sm_sc = 1;
    ble_hs_cfg.sm_our_key_dist = BLE_SM_PAIR_KEY_DIST_ENC | BLE_SM_PAIR_KEY_DIST_ID;
    ble_hs_cfg.sm_their_key_dist = BLE_SM_PAIR_KEY_DIST_ENC | BLE_SM_PAIR_KEY_DIST_ID;

    ble_svc_gap_init();
    ble_svc_gatt_init();

    int rc = ble_gatts_count_cfg(s_svcs);
    if (rc == 0) {
        rc = ble_gatts_add_svcs(s_svcs);
    }
    if (rc != 0) {
        ESP_LOGE(TAG, "GATT table rc=%d", rc);
        return ESP_FAIL;
    }
    ble_svc_gap_device_name_set(CONFIG_HOOP_BLE_NAME);
    ble_att_set_preferred_mtu(247);
    ble_store_config_init();

    s_notify_timer = xTimerCreate("ble_stat", pdMS_TO_TICKS(1000), pdTRUE, NULL, notify_timer_cb);
    if (s_notify_timer) {
        xTimerStart(s_notify_timer, 0);
    }

    nimble_port_freertos_init(host_task);   /* host task pinned to core 0 by sdkconfig */
    return ESP_OK;
}

/* ---------- public control ---------- */

void ble_service_start_advertising(uint32_t window_s)
{
    s_adv_deadline_us = window_s ? esp_timer_get_time() + (int64_t)window_s * 1000000 : 0;
    s_adv_wanted = true;
    adv_start();
}

void ble_service_stop_advertising(void)
{
    s_adv_wanted = false;
    if (s_synced && ble_gap_adv_active()) {
        ble_gap_adv_stop();
    }
}

bool ble_service_is_advertising(void)
{
    return s_synced && ble_gap_adv_active();
}

bool ble_service_is_connected(void)
{
    return s_conn != BLE_HS_CONN_HANDLE_NONE;
}

void ble_service_open_pairing(uint32_t seconds)
{
    s_pairing_open_until_us = esp_timer_get_time() + (int64_t)seconds * 1000000;
    ESP_LOGI(TAG, "pairing window open for %lu s", (unsigned long)seconds);
}

void ble_service_clear_bonds(void)
{
    if (s_conn != BLE_HS_CONN_HANDLE_NONE) {
        ble_gap_terminate(s_conn, BLE_ERR_REM_USER_CONN_TERM);
    }
    ble_store_clear();
    ESP_LOGW(TAG, "all bonds erased");
}
