/*
 * ota_update.h - firmware update pushed by the app over BLE.
 * Image is streamed into the inactive OTA slot, verified with CRC-32
 * (zlib / ISO-HDLC) + ESP-IDF image validation, then the device reboots.
 * Bootloader rollback is enabled: a new image that fails to start is reverted.
 */
#pragma once

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include "esp_err.h"

esp_err_t ota_update_begin(uint32_t image_size);
esp_err_t ota_update_write(const uint8_t *data, size_t len);
esp_err_t ota_update_finish(uint32_t expected_crc32);   /* reboots ~1 s later on success */
void      ota_update_abort(void);

bool      ota_update_in_progress(void);
uint32_t  ota_update_received(void);
uint32_t  ota_update_size(void);
uint8_t   ota_update_progress_pct(void);
