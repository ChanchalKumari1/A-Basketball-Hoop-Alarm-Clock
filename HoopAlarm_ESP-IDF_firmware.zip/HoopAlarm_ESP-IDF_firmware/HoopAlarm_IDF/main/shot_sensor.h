/*
 * shot_sensor.h - IR break-beam / IR rim sensor that detects the ball
 * passing through the hoop.
 *
 * A "made shot" = beam interrupted for SHOT_MIN_US..SHOT_MAX_MS and then
 * restored (a clean pass). Short glitches and long blockages (hand in the
 * hoop, ball stuck on the rim) are rejected. Edges are timestamped in the ISR.
 */
#pragma once

#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"

typedef void (*shot_cb_t)(uint32_t pass_ms);

/* Call from CORE_REALTIME (installs the GPIO ISR on that core). */
esp_err_t shot_sensor_init(shot_cb_t cb);

/* Power the emitter and start counting shots (only while an alarm rings). */
void shot_sensor_arm(bool armed);

/* Ignore beam events for the next `ms` (servo moving / ball rolling). */
void shot_sensor_blank(uint32_t ms);

/* true if the beam has been blocked longer than SHOT_MAX_MS */
bool shot_sensor_is_blocked(void);
