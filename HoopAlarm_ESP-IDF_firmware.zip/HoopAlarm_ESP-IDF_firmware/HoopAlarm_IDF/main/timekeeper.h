/*
 * timekeeper.h - 1 Hz hardware-timer tick that is phase-locked to the DS3231.
 *
 * The DS3231 is the source of truth. A GPTimer interrupt advances a local
 * seconds counter exactly on DS3231 second boundaries, so the alarm check
 * runs from a hardware interrupt, not from a polling loop. The counter is
 * compared against the DS3231 every CONFIG_HOOP_RTC_RESYNC_MIN minutes and
 * once a day at 03:00, and re-aligned if they disagree (e.g. I2C hiccup).
 */
#pragma once

#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"
#include "freertos/FreeRTOS.h"

/* Called from the timer ISR every second with the new local epoch. Must be IRAM-safe. */
typedef void (*tk_tick_cb_t)(uint32_t epoch, BaseType_t *higher_prio_woken);

/* Call from the core that should own the tick interrupt (core 1). */
esp_err_t timekeeper_init(tk_tick_cb_t cb);

uint32_t  timekeeper_now(void);
bool      timekeeper_valid(void);

/* Set wall-clock time (writes the DS3231 and re-phases the tick). Any task. */
esp_err_t timekeeper_set_time(uint32_t epoch);

void      timekeeper_request_resync(void);
int16_t   timekeeper_temperature(void);   /* DS3231 temperature x100, INT16_MIN if unknown */
