/*
 * ble_service.h - NimBLE peripheral with the custom "Hoop Alarm" GATT service.
 * Protocol: docs/BLE_PROTOCOL.md. All configuration characteristics require an
 * authenticated (passkey) bonded link. Runs on core 0.
 */
#pragma once

#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"

esp_err_t ble_service_init(void);

void ble_service_start_advertising(uint32_t window_s);   /* 0 = until stopped */
void ble_service_stop_advertising(void);
bool ble_service_is_advertising(void);
bool ble_service_is_connected(void);

void ble_service_open_pairing(uint32_t seconds);          /* allow a new phone to bond */
void ble_service_clear_bonds(void);
