/*
 * display.c - shift-register 7-segment driver
 */
#include <string.h>
#include "display.h"
#include "app_config.h"
#include "driver/spi_master.h"
#include "driver/ledc.h"
#include "esp_check.h"
#include "esp_log.h"

#if HOOP_HAS_DISPLAY

static const char *TAG = "display";

/* Logical segment bits used by the font: a=0 b=1 c=2 d=3 e=4 f=5 g=6 dp=7.
 * SEG_TO_OUTPUT[n] = shift-register output (QA=0..QH=7) wired to logical segment n.
 * Edit this table if the PCB routes segments differently. */
static const uint8_t SEG_TO_OUTPUT[8] = { 0, 1, 2, 3, 4, 5, 6, 7 };

static spi_device_handle_t s_spi;
static uint8_t             s_last[HOOP_DISPLAY_DIGITS];
static uint8_t             s_brightness = 100;

static uint8_t glyph(char c)
{
    switch (c) {
    case '0': case 'O': return 0x3F;
    case '1': return 0x06;
    case '2': case 'Z': case 'z': return 0x5B;
    case '3': return 0x4F;
    case '4': return 0x66;
    case '5': case 'S': case 's': return 0x6D;
    case '6': return 0x7D;
    case '7': return 0x07;
    case '8': case 'B': return 0x7F;
    case '9': case 'g': return 0x6F;
    case 'A': case 'a': return 0x77;
    case 'b': return 0x7C;
    case 'C': return 0x39;
    case 'c': return 0x58;
    case 'd': case 'D': return 0x5E;
    case 'E': case 'e': return 0x79;
    case 'F': case 'f': return 0x71;
    case 'G': return 0x3D;
    case 'H': return 0x76;
    case 'h': return 0x74;
    case 'I': return 0x30;
    case 'i': return 0x10;
    case 'J': case 'j': return 0x1E;
    case 'L': case 'l': return 0x38;
    case 'n': case 'N': return 0x54;
    case 'o': return 0x5C;
    case 'P': case 'p': return 0x73;
    case 'q': case 'Q': return 0x67;
    case 'r': case 'R': return 0x50;
    case 't': case 'T': return 0x78;
    case 'U': return 0x3E;
    case 'u': case 'v': case 'V': return 0x1C;
    case 'y': case 'Y': return 0x6E;
    case '-': return 0x40;
    case '_': return 0x08;
    case '=': return 0x48;
    case '^': return 0x63;   /* degree sign */
    default:  return 0x00;
    }
}

static uint8_t map_to_outputs(uint8_t logical)
{
    uint8_t out = 0;
    for (int i = 0; i < 8; i++) {
        if (logical & (1u << i)) {
            out |= (uint8_t)(1u << SEG_TO_OUTPUT[i]);
        }
    }
    return HOOP_DISPLAY_INVERT ? (uint8_t)~out : out;
}

static void push(const uint8_t *segs)
{
    if (memcmp(segs, s_last, HOOP_DISPLAY_DIGITS) == 0) {
        return;
    }
    memcpy(s_last, segs, HOOP_DISPLAY_DIGITS);

    /* The first byte clocked out ends up in the register furthest down the chain. */
    uint8_t tx[HOOP_DISPLAY_DIGITS];
    for (int i = 0; i < HOOP_DISPLAY_DIGITS; i++) {
        int digit = HOOP_DISPLAY_CHAIN_REVERSED ? i : (HOOP_DISPLAY_DIGITS - 1 - i);
        tx[i] = map_to_outputs(segs[digit]);
    }
    spi_transaction_t t = {
        .length = HOOP_DISPLAY_DIGITS * 8,
        .tx_buffer = tx,
    };
    spi_device_polling_transmit(s_spi, &t);   /* CS rising edge at the end = latch */
}

static void apply_brightness(uint8_t pct)
{
    uint32_t duty = (uint32_t)pct * 255u / 100u;
    ledc_set_duty(HOOP_LEDC_MODE, DISP_LEDC_CHANNEL, duty);
    ledc_update_duty(HOOP_LEDC_MODE, DISP_LEDC_CHANNEL);
}

esp_err_t display_init(void)
{
    spi_bus_config_t bus = {
        .mosi_io_num = PIN_DISP_MOSI,
        .miso_io_num = -1,
        .sclk_io_num = PIN_DISP_SCLK,
        .quadwp_io_num = -1,
        .quadhd_io_num = -1,
        .max_transfer_sz = 16,
    };
    ESP_RETURN_ON_ERROR(spi_bus_initialize(SPI3_HOST, &bus, SPI_DMA_DISABLED), TAG, "bus");

    spi_device_interface_config_t dev = {
        .clock_speed_hz = 1 * 1000 * 1000,   /* long ribbon to the modules: keep it slow */
        .mode = 0,
        .spics_io_num = PIN_DISP_LATCH,
        .queue_size = 1,
    };
    ESP_RETURN_ON_ERROR(spi_bus_add_device(SPI3_HOST, &dev, &s_spi), TAG, "dev");

    /* /OE is active low -> invert the PWM so duty = "on" time */
    ledc_timer_config_t t = {
        .speed_mode = HOOP_LEDC_MODE,
        .duty_resolution = LEDC_TIMER_8_BIT,
        .timer_num = DISP_LEDC_TIMER,
        .freq_hz = 5000,
        .clk_cfg = LEDC_AUTO_CLK,
    };
    ESP_RETURN_ON_ERROR(ledc_timer_config(&t), TAG, "oe timer");
    ledc_channel_config_t c = {
        .gpio_num = PIN_DISP_OE,
        .speed_mode = HOOP_LEDC_MODE,
        .channel = DISP_LEDC_CHANNEL,
        .timer_sel = DISP_LEDC_TIMER,
        .duty = 0,
        .hpoint = 0,
        .intr_type = LEDC_INTR_DISABLE,
        .flags.output_invert = 1,
    };
    ESP_RETURN_ON_ERROR(ledc_channel_config(&c), TAG, "oe channel");

    memset(s_last, 0xAA, sizeof(s_last));   /* force first push */
    uint8_t blank[HOOP_DISPLAY_DIGITS] = {0};
    push(blank);
    apply_brightness(s_brightness);
    ESP_LOGI(TAG, "%d-digit display ready", HOOP_DISPLAY_DIGITS);
    return ESP_OK;
}

void display_render(const char *chars, uint8_t dp_mask)
{
    uint8_t segs[HOOP_DISPLAY_DIGITS];
    for (int i = 0; i < HOOP_DISPLAY_DIGITS; i++) {
        segs[i] = glyph(chars[i]) | ((dp_mask & (1u << i)) ? 0x80 : 0x00);
    }
    push(segs);
}

void display_print(const char *text)
{
    char    chars[HOOP_DISPLAY_DIGITS];
    uint8_t dp = 0;
    int     pos = 0;
    memset(chars, ' ', sizeof(chars));
    for (const char *p = text; *p && pos <= HOOP_DISPLAY_DIGITS; p++) {
        if (*p == '.' && pos > 0) {
            dp |= (uint8_t)(1u << (pos - 1));
        } else if (pos < HOOP_DISPLAY_DIGITS) {
            chars[pos++] = *p;
        } else {
            break;
        }
    }
    display_render(chars, dp);
}

void display_set_brightness(uint8_t percent)
{
    if (percent > 100) {
        percent = 100;
    }
    if (percent != s_brightness) {
        s_brightness = percent;
        apply_brightness(percent);
    }
}

void display_off(void)
{
    s_brightness = 0;
    apply_brightness(0);
    uint8_t blank[HOOP_DISPLAY_DIGITS] = {0};
    push(blank);
}

#else  /* no display fitted: keep the API as no-ops */

esp_err_t display_init(void) { return ESP_OK; }
void display_render(const char *chars, uint8_t dp_mask) { (void)chars; (void)dp_mask; }
void display_print(const char *text) { (void)text; }
void display_set_brightness(uint8_t percent) { (void)percent; }
void display_off(void) { }

#endif
