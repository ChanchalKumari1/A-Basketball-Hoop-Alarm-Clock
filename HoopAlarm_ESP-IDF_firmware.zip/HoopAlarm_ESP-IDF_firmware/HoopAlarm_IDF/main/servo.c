/*
 * servo.c - ball release mechanism (SG90, 50 Hz LEDC)
 */
#include "servo.h"
#include "app_config.h"
#include "shot_sensor.h"
#include "driver/ledc.h"
#include "driver/gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_check.h"
#include "esp_log.h"

static const char *TAG = "servo";

#define SERVO_FREQ_HZ     50
#define SERVO_BITS        LEDC_TIMER_14_BIT
#define SERVO_PERIOD_US   20000
#define SERVO_MAX_DUTY    ((1u << 14) - 1)

static TaskHandle_t  s_task;
static volatile bool s_busy;
static bool          s_ready;

static uint32_t angle_to_duty(int deg)
{
    if (deg < 0) {
        deg = 0;
    } else if (deg > 180) {
        deg = 180;
    }
    uint32_t us = CONFIG_HOOP_SERVO_MIN_US +
                  (uint32_t)(CONFIG_HOOP_SERVO_MAX_US - CONFIG_HOOP_SERVO_MIN_US) * (uint32_t)deg / 180u;
    return us * (SERVO_MAX_DUTY + 1) / SERVO_PERIOD_US;
}

static void set_duty(uint32_t duty)
{
    ledc_set_duty(HOOP_LEDC_MODE, SERVO_LEDC_CHANNEL, duty);
    ledc_update_duty(HOOP_LEDC_MODE, SERVO_LEDC_CHANNEL);
}

static void power(bool on)
{
    if (PIN_SERVO_PWR >= 0) {
        gpio_set_level(PIN_SERVO_PWR, on ? 1 : 0);
    }
}

static void servo_task(void *arg)
{
    for (;;) {
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);

        /* the falling ball / arm vibration must not count as a basket */
        shot_sensor_blank(HOOP_SERVO_CYCLE_MS + 300);

        power(true);
        set_duty(angle_to_duty(CONFIG_HOOP_SERVO_HOLD_DEG));
        vTaskDelay(pdMS_TO_TICKS(40));                       /* bulk cap charges, servo wakes */
        set_duty(angle_to_duty(CONFIG_HOOP_SERVO_RELEASE_DEG));
        vTaskDelay(pdMS_TO_TICKS(350));                      /* lip opens, one ball rolls out */
        set_duty(angle_to_duty(CONFIG_HOOP_SERVO_HOLD_DEG));
        vTaskDelay(pdMS_TO_TICKS(450));                      /* lip closes behind it */
        set_duty(0);                                         /* stop pulses: no jitter, no hum */
        power(false);

        ESP_LOGI(TAG, "ball released");
        s_busy = false;
    }
}

esp_err_t servo_init(void)
{
#if HOOP_HAS_SERVO
    if (PIN_SERVO_PWR >= 0) {
        gpio_config_t io = { .pin_bit_mask = 1ULL << PIN_SERVO_PWR, .mode = GPIO_MODE_OUTPUT };
        ESP_RETURN_ON_ERROR(gpio_config(&io), TAG, "pwr gpio");
        gpio_set_level(PIN_SERVO_PWR, 0);
    }

    ledc_timer_config_t t = {
        .speed_mode = HOOP_LEDC_MODE,
        .duty_resolution = SERVO_BITS,
        .timer_num = SERVO_LEDC_TIMER,
        .freq_hz = SERVO_FREQ_HZ,
        .clk_cfg = LEDC_AUTO_CLK,
    };
    ESP_RETURN_ON_ERROR(ledc_timer_config(&t), TAG, "timer");

    ledc_channel_config_t c = {
        .gpio_num = PIN_SERVO,
        .speed_mode = HOOP_LEDC_MODE,
        .channel = SERVO_LEDC_CHANNEL,
        .timer_sel = SERVO_LEDC_TIMER,
        .duty = 0,
        .hpoint = 0,
        .intr_type = LEDC_INTR_DISABLE,
    };
    ESP_RETURN_ON_ERROR(ledc_channel_config(&c), TAG, "channel");

    BaseType_t ok = xTaskCreatePinnedToCore(servo_task, "servo", 2560, NULL, PRIO_SERVO,
                                            &s_task, CORE_REALTIME);
    ESP_RETURN_ON_FALSE(ok == pdPASS, ESP_ERR_NO_MEM, TAG, "task");
    s_ready = true;
    ESP_LOGI(TAG, "servo on GPIO%d, hold %d deg, release %d deg", PIN_SERVO,
             CONFIG_HOOP_SERVO_HOLD_DEG, CONFIG_HOOP_SERVO_RELEASE_DEG);
#endif
    return ESP_OK;
}

bool servo_request_drop(void)
{
    if (!s_ready || s_busy) {
        return false;
    }
    s_busy = true;
    xTaskNotifyGive(s_task);
    return true;
}

bool servo_busy(void)
{
    return s_busy;
}

void servo_power_off(void)
{
    if (!s_ready) {
        return;
    }
    set_duty(0);
    power(false);
}
