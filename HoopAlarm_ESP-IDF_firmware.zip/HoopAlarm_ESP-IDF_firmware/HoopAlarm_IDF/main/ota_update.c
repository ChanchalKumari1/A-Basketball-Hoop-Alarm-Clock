/*
 * ota_update.c - BLE OTA backend
 */
#include "ota_update.h"
#include "esp_ota_ops.h"
#include "esp_rom_crc.h"
#include "esp_timer.h"
#include "esp_system.h"
#include "esp_log.h"

static const char *TAG = "ota";

static esp_ota_handle_t       s_handle;
static const esp_partition_t *s_part;
static volatile bool          s_active;
static uint32_t               s_size;
static volatile uint32_t      s_recv;
static uint32_t               s_crc;
static esp_timer_handle_t     s_reboot_timer;

static void reboot_cb(void *arg)
{
    ESP_LOGW(TAG, "rebooting into new firmware");
    esp_restart();
}

esp_err_t ota_update_begin(uint32_t image_size)
{
    if (s_active) {
        ota_update_abort();
    }
    s_part = esp_ota_get_next_update_partition(NULL);
    if (!s_part) {
        return ESP_ERR_NOT_FOUND;
    }
    if (image_size == 0 || image_size > s_part->size) {
        return ESP_ERR_INVALID_SIZE;
    }
    /* sequential writes erase sector-by-sector, so the BLE link isn't stalled by a
     * full-partition erase */
    esp_err_t err = esp_ota_begin(s_part, OTA_WITH_SEQUENTIAL_WRITES, &s_handle);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "begin failed: %s", esp_err_to_name(err));
        return err;
    }
    s_size = image_size;
    s_recv = 0;
    s_crc = 0;
    s_active = true;
    ESP_LOGI(TAG, "OTA started: %lu bytes -> %s", (unsigned long)image_size, s_part->label);
    return ESP_OK;
}

esp_err_t ota_update_write(const uint8_t *data, size_t len)
{
    if (!s_active) {
        return ESP_ERR_INVALID_STATE;
    }
    if (s_recv + len > s_size) {
        ota_update_abort();
        return ESP_ERR_INVALID_SIZE;
    }
    esp_err_t err = esp_ota_write(s_handle, data, len);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "write failed: %s", esp_err_to_name(err));
        ota_update_abort();
        return err;
    }
    s_crc = esp_rom_crc32_le(s_crc, data, (uint32_t)len);
    s_recv += (uint32_t)len;
    return ESP_OK;
}

esp_err_t ota_update_finish(uint32_t expected_crc32)
{
    if (!s_active) {
        return ESP_ERR_INVALID_STATE;
    }
    if (s_recv != s_size) {
        ESP_LOGE(TAG, "incomplete image %lu/%lu", (unsigned long)s_recv, (unsigned long)s_size);
        ota_update_abort();
        return ESP_ERR_INVALID_SIZE;
    }
    if (s_crc != expected_crc32) {
        ESP_LOGE(TAG, "CRC mismatch: got %08lx expected %08lx",
                 (unsigned long)s_crc, (unsigned long)expected_crc32);
        ota_update_abort();
        return ESP_ERR_INVALID_CRC;
    }
    esp_err_t err = esp_ota_end(s_handle);          /* validates the app image */
    s_active = false;
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "image invalid: %s", esp_err_to_name(err));
        return err;
    }
    err = esp_ota_set_boot_partition(s_part);
    if (err != ESP_OK) {
        return err;
    }

    const esp_timer_create_args_t args = { .callback = reboot_cb, .name = "ota_reboot" };
    if (esp_timer_create(&args, &s_reboot_timer) == ESP_OK) {
        esp_timer_start_once(s_reboot_timer, 1000000);   /* let the BLE write response go out */
    } else {
        esp_restart();
    }
    ESP_LOGI(TAG, "OTA complete");
    return ESP_OK;
}

void ota_update_abort(void)
{
    if (s_active) {
        esp_ota_abort(s_handle);
        s_active = false;
        ESP_LOGW(TAG, "OTA aborted at %lu bytes", (unsigned long)s_recv);
    }
}

bool     ota_update_in_progress(void) { return s_active; }
uint32_t ota_update_received(void)    { return s_recv; }
uint32_t ota_update_size(void)        { return s_size; }

uint8_t ota_update_progress_pct(void)
{
    return s_size ? (uint8_t)((uint64_t)s_recv * 100u / s_size) : 0;
}
